export const foo = 'bar';
