# smoke test

This e2e exercises the repo from an end-users perpective.
It catches mistakes in our install instructions, or usages that fail when called from an "external" repository to rules_rollup.
