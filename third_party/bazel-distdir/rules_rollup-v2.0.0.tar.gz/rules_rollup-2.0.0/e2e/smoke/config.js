module.exports = { plugins: [] }
