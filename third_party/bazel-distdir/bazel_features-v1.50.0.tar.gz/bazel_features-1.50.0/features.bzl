"""Defines all the features this module supports detecting."""

load("@bazel_features_globals//:globals.bzl", "globals")
load("//private:util.bzl", "ge", "ge_same_major", "gt", "lt")

_apple = struct(
    # From Bazel 8.0.0 on, the `xcode_version_flag` is available and the `XcodeVersionConfig`
    # signature changed to migrate Xcode configuration to Starlark.
    # https://github.com/bazelbuild/bazel/commit/26c6add3f9809611ad3795bce1e5c0fb37902902
    xcode_config_migrated = ge("8.0.0"),
)

_cc = struct(
    # Whether @bazel_tools//tools/cpp:optional_current_cc_toolchain and the `mandatory` parameter
    # on find_cpp_toolchain are available (#17308).
    # Note: While the target and parameter are available in 6.1.0, they only take effect in Bazel 7.
    find_cpp_toolchain_has_mandatory_param = ge("6.1.0"),
    # Whether `dsym_path` is no longer incorrectly quoted
    # https://github.com/bazelbuild/bazel/commit/7a04b220f30b92d11049157279ef0cfb5130870d
    fixed_dsym_path_quoting = ge_same_major("7.2.0") or ge("8.0.0-pre.20240404.3"),
    # Note: In Bazel 6.3 the `grep_includes` parameter is optional and a no-op in the cc_common API
    # In future Bazel versions it will be removed altogether.
    grep_includes_is_optional = ge("6.3.0"),
    # From 7.0.0-pre.20230724.1 on `ObjcProvider` no longer contains linking info
    # https://github.com/bazelbuild/bazel/commit/426f2254669f62b7d332094a0af6d4dc6200ad51
    objc_linking_info_migrated = ge("7.0.0-pre.20230724.1"),
    # https://github.com/bazelbuild/bazel/commit/c8c3878088cb706b820d506a682e1156b7e8c64d
    swift_fragment_removed = ge("8.0.0-pre.20240101.1"),
    # Whether the Unix C/C++ toolchain passes -undefined dynamic_lookup to the
    # macOS linker.  Added in commit
    # https://github.com/bazelbuild/bazel/commit/314cf1f9e4b332955c4800b2451db4e926c3e092
    # and removed again in commit
    # https://github.com/bazelbuild/bazel/commit/4853dfd02ac7440a04caada830b7b61b6081bdfe.
    undefined_dynamic_lookup = ge("0.25.0") and lt("7.0.0-pre.20230118.2"),
    # Whether the treat_warnings_as_errors feature works on macOS.
    # https://github.com/bazelbuild/bazel/commit/3d7c5ae47e2a02ccd81eb8024f22d56ae7811c9b
    treat_warnings_as_errors_works_on_macos = ge("7.1.0"),
    # Whether protobuf repository can access private C++ features
    # https://github.com/bazelbuild/bazel/commit/6022ee81705295704dcbedb2ceb5869049191121
    protobuf_on_allowlist = ge("8.0.0"),
    # Whether cc_{binary,test} can be extended.
    # https://github.com/bazelbuild/bazel/commit/b746d663da71f937390809f0e8368112cafafb56
    rules_support_extension = ge("8.0.1"),
    # Whether cc_toolchain has the generate_modmap attribute.
    # https://github.com/bazelbuild/bazel/commit/8028655414a189b6897b1b51e3e43b5711e0af98
    cc_toolchain_has_generate_modmap = gt("9.0.0-pre.20250716.1"),
    # Whether cc_toolchain is imlemented in starlark.
    # https://github.com/bazelbuild/bazel/commit/b9f1721f79bb1f21e39d74c13878a33f05fa7034
    supports_starlarkified_toolchains = gt("9.0.0-pre.20250911"),
    # Whether cc_common is taken from rules_cc, in its starlarkified version,
    # rather than the builtin, typically native cc_common of Bazel 7 and Bazel 8.
    # One behavioral change between the two comes from
    # https://github.com/bazelbuild/bazel/pull/25750, and it is expected that more
    # will accumulate as cc_common in rules_cc evolves further while cc_common in
    # Bazel 7 and Bazel 8 stays as it is.
    # The tests in rules_cc need to be able to take this into account.
    # The compatibility proxy in rules_cc/cc/extensions.bzl:31 switches from native to
    # rules_cc at Bazel version 9.0.0-pre.20250911.
    cc_common_is_in_rules_cc = ge("9.0.0-pre.20250911"),
    # Whether toolchain features can mark paths for path mapping via ${path:...} patterns.
    # https://github.com/bazelbuild/bazel/commit/41a36ff029340823700e2f4dec0c7cf71fcbdb31
    # https://github.com/bazelbuild/bazel/commit/39386503ad55cfad38290f45a8d3732d5b2cd9ac
    supports_path_variable_patterns = ge_same_major("9.1.0") or ge("10.0.0-pre.20260408.3"),
    # Internal only, don't use outside rules_cc.
    # https://github.com/bazelbuild/bazel/commit/d788aa269a3300771696a0f9e00868a43cadf7d3
    _get_link_args_has_param_file_name = ge("10.0.0-pre.20260608.1"),
    
)

_docs = struct(
    # The stardoc output changed in https://github.com/bazelbuild/bazel/commit/bd1c3af2ea14e81268e940d2b8ba5ad00c3f08d7
    # This may be required for "diff tests" that assert on the generated API docs.
    kwargs_name_with_double_star = ge("8.0.0-pre.20240603.2"),
    # Starting with Bazel 8.1.0, all strings exported to Stardoc (docstrings,
    # rule names, etc.) are interpreted as UTF-8.  Previously, they were
    # interpreted as Latin-1, resulting in double-encoding if the underlying
    # Starlark file was actually UTF-8-encoded.  See
    # https://github.com/bazelbuild/bazel/pull/24935.
    utf8_enabled = ge("8.1.0"),
)

_external_deps = struct(
    # Whether --enable_bzlmod is set, and thus, whether str(Label(...)) produces canonical label
    # literals (i.e., "@@repo//pkg:file").
    is_bzlmod_enabled = str(Label("//:invalid")).startswith("@@"),
    # Whether module_extension has the os_dependent and arch_dependent parameters.
    # https://github.com/bazelbuild/bazel/commit/970b9dda7cd215a29d73a53871500bc4e2dc6142
    module_extension_has_os_arch_dependent = ge("6.4.0"),
    # Whether repository_ctx#download has the block parameter, allowing parallel downloads (#19674)
    download_has_block_param = ge("7.1.0"),
    # Whether repository_ctx#download has the headers parameter, allowing arbitrary headers (#17829)
    download_has_headers_param = ge("7.1.0"),
    # Whether repository_ctx#extract has unicode filename extraction fix (#18448)
    extract_supports_unicode_filenames = ge("6.4.0"),
    # Whether the `bazel mod tidy` subcommand is available (#19674)
    # https://github.com/bazelbuild/bazel/commit/9f0f23211293589d812cb9ea4aaaead52486c52e
    # https://github.com/bazelbuild/bazel/commit/9fe80d33e129de521b696c330802aad9782db18f
    bazel_mod_tidy = ge_same_major("7.1.0") or ge("8.0.0-pre.20240213.1"),
    # Whether module_ctx.extension_metadata has the reproducible parameter (#19674)
    # https://github.com/bazelbuild/bazel/commit/c796aba6ee36970956ea32b46a2f121bb4d1818a
    # https://github.com/bazelbuild/bazel/commit/e730201e6bf8d6c1c80433b5b42305c3167a8660
    extension_metadata_has_reproducible = ge_same_major("7.1.0") or ge("8.0.0-pre.20240213.1"),
    # Whether repository_ctx.repo_metadata has the reproducible parameter (#25938)
    # https://github.com/bazelbuild/bazel/commit/ad74aa5d9e29e7d4ab3043328ee25901be9e14f6
    # https://github.com/bazelbuild/bazel/commit/33ee3b5acebbfffe74ef2ab8c3f437cb38382843
    repo_metadata_has_reproducible = ge_same_major("8.3.0") or ge("9.0.0-pre.20250831.1"),
    # Whether repository_ctx#getenv exists (#19511)
    # Note: This primarily targets conditionally adding environ
    # attributes to repository rule declarations.  Inside repository rule
    # implementations, consider using the simpler and more descriptive
    # hasattr(repository_ctx, "getenv") as an alternative.
    # https://github.com/bazelbuild/bazel/commit/c230e39fb225edd206ed0aa07cfcdd8c51589965
    # https://github.com/bazelbuild/bazel/commit/25815511434d17f2843f73e0ff5231f3d80bc44e
    repository_ctx_has_getenv = ge_same_major("7.1.0") or ge("8.0.0-pre.20240128.3"),
    # Whether rctx.symlink calls get rewritten to be relative symlinks when the repo is cached.
    # https://github.com/bazelbuild/bazel/commit/2ce32e70485ab807e5188efcb696927ec6606a3e
    # https://github.com/bazelbuild/bazel/commit/4edfe3276c127f73145018f4973cc422da61f05d
    repo_rules_relativize_symlinks = ge_same_major("9.0.1") or ge("10.0.0-pre.20260322.2"),
    # Whether facts are supported
    #
    # Only use this when a module_ctx is not available.
    # Otherwise use `hasattr(module_ctx, "facts")`
    # https://github.com/bazelbuild/bazel/commit/0b3c45f46d144d07fd4d562f55069bba0cd49a09
    has_facts = ge("8.5.0"),
)

_flags = struct(
    # This flag was renamed in https://github.com/bazelbuild/bazel/pull/18313
    allow_unresolved_symlinks = (
        "allow_unresolved_symlinks" if ge("7.0.0-pre.20230628.2") else "experimental_allow_unresolved_symlinks"
    ),
)

_java = struct(
    # Whether the JavaInfo constructor has add_exports/add_opens named parameters. Added in
    # https://github.com/bazelbuild/bazel/commit/d2783a3c3d1b899beb674e029bfea3519062e8be (HEAD)
    # https://github.com/bazelbuild/bazel/commit/e2249f91ff84541565d8ba841592a0a8a43fcb66 (7.0.0)
    java_info_constructor_module_flags = ge_same_major("7.0.0") or ge("8.0.0-pre.20240101.1"),
)

_proto = struct(
    # Bazel 7.0.0 introduced ProtoInfo in Starlark, which can be constructed and has different fields
    # than ProtoInfo in previous versions. The check is needed for proto rules that are using ProtoInfo from Bazel.
    starlark_proto_info = ge("7.0.0"),
)

_rules = struct(
    # Whether runfiles may contain all characters. Support for all characters added in:
    # https://github.com/bazelbuild/bazel/commit/c9115305cb81e7fe645f91ca790642cab136b2a1
    all_characters_allowed_in_runfiles = ge("7.4.0"),
    # Whether the computed_substitutions parameter of ctx.actions.expand_template and ctx.actions.template_dict are stable.
    # https://github.com/bazelbuild/bazel/commit/61c31d255b6ba65c372253f65043d6ea3f10e1f9
    expand_template_has_computed_substitutions = ge("7.0.0-pre.20231011.2"),
    # Whether TemplateDict#add_joined allows the map_each callback to return a list of strings (#17306)
    template_dict_map_each_can_return_list = ge("6.1.0"),
    # Whether coverage_common.instrumented_files_info spports the
    # metadata_files parameter.  Introduced in commit
    # https://github.com/bazelbuild/bazel/commit/ef54ef5d17a013c863c4e2fb0583e6bd209645f2.
    instrumented_files_info_has_metadata_files = ge("7.0.0-pre.20230710.5"),
    # Whether coverage_common.instrumented_files_info supports the
    # baseline_coverage_files parameter.  Introduced in commit
    # https://github.com/bazelbuild/bazel/commit/e672aceda6fba37171bebce77c5ee62442337c23
    instrumented_files_info_has_baseline_coverage_files = gt("9.0.0-pre.20250610.2"),
    # Whether treeartifacts can have symlinks pointing outside of the tree artifact. (#21263)
    permits_treeartifact_uplevel_symlinks = ge("7.1.0"),
    # Whether rule extension APIs are available by default
    rule_extension_apis_available = ge("8.0.0rc1"),
    # Whether Starlark anaylsis tests can transition on incompatible/experimental flags (#25536)
    analysis_tests_can_transition_on_experimental_incompatible_flags = ge("8.2.0"),
    # Whether the attr_aspects and toolchains_aspects attributes on aspect accept Starlark functions.
    # https://github.com/bazelbuild/bazel/commit/c422744caa072c66311a937049504901bc674b7d
    aspect_propagation_context = ge("9.0.0-pre.20250311.1"),
    # Whether structs can have fields names 'to_json' and 'to_proto'.
    # https://github.com/bazelbuild/bazel/commit/db5906870bdcb1631e1b18be8637aa21b79cf943
    no_struct_field_denylist = ge("9.0.0-pre.20250128.3"),
    # Whether the new merkle cache exists, which is on by default and handles source directories efficiently.
    # https://github.com/bazelbuild/bazel/commit/30ca50950fdaff032925efe64c2690a9f05e074d
    merkle_cache_v2 = gt("9.0.0-pre.20251014.1"),
    # Whether ctx.actions.symlink accepts a target_type argument to create junctions on Windows.
    # https://github.com/bazelbuild/bazel/commit/b9bbda939cddab807e34559cb7ee798febfa3861
    symlink_action_has_target_type = ge_same_major("8.6.0") or ge("9.0.0"),
    # Whether ctx.actions.write accepts a mnemonic parameter.
    # https://github.com/bazelbuild/bazel/commit/34673f3371229fe310b433cf6ade353b9610f9fb
    write_action_has_mnemonic = ge("9.0.0-pre.20250710.1"),
    # Whether ctx.actions.write supports the execution_requirements parameter.
    # https://github.com/bazelbuild/bazel/commit/2e4abf8b2252512947298300a03750574f050ce6
    # https://github.com/bazel-io/bazel/commit/825369f7231b11f2d966bf8f3ef2d4905eae1344
    write_action_has_execution_requirements = ge_same_major("9.1.0") or gt("10.0.0-pre.20260120.1"),

    # Whether ctx.configuration.is_tool_configuration is public API
    # https://github.com/bazelbuild/bazel/commit/84c0253add3784b75ff08b6d049a7f152c7b7532
    is_tool_configuration_public = ge_same_major("8.7.0") or ge_same_major("9.1.0") or ge_same_major("10.0.0-pre.20260329.2"),
    # Whether constraint_setting has the refines_constraint_value attribute.
    # https://github.com/bazelbuild/bazel/commit/a59ad366453bb731b255916277d34d5d536ca696
    constraint_setting_has_refines_constraint_value = gt("10.0.0-pre.20260524.1"),

    # Internal only, don't use outside rules_java, rules_python & rules_shell.
    # TODO: Use a larger version range after cherry-picking
    # https://github.com/bazelbuild/bazel/commit/e81949554f3ecab5e2c4afd79031f498f36427fe
    _has_launcher_maker_toolchain = ge_same_major("8.3.0") or ge("9.0.0-pre.20250516.1"),
)

_toolchains = struct(
    # Whether the mandatory parameter is available on the config_common.toolchain_type function, and thus, whether optional toolchains are supported
    # https://bazel.build/versions/6.0.0/extending/toolchains#optional-toolchains
    has_optional_toolchains = ge("6.0.0"),
    # Whether the use_target_platform_constraints attribute is available on the toolchain rule (#25123)
    # https://github.com/bazelbuild/bazel/commit/ba9e539a086859afaa4d2b3bf8d3afb44bcd06ce
    has_use_target_platform_constraints = ge("8.2.0"),
    # Whether genrule.toolchains accepts toolchain_type targets
    # https://github.com/bazelbuild/bazel/commit/0e876b1794d4db58b72949014401d22cc65d94a1
    genrule_accepts_toolchain_types = ge_same_major("8.3.0") or ge("9.0.0-pre.20241016.1"),
    # Whether the default_test_toolchain_type exists
    # https://github.com/bazelbuild/bazel/commit/7d685648a8a9e4ea203f95ad983088a17103f4a6
    has_default_test_toolchain_type = ge("9.0.0-pre.20250324.2"),
)

bazel_features = struct(
    apple = _apple,
    cc = _cc,
    docs = _docs,
    external_deps = _external_deps,
    flags = _flags,
    globals = globals,
    java = _java,
    proto = _proto,
    rules = _rules,
    toolchains = _toolchains,
)
