#!/bin/bash

set -euo pipefail

echo 'hello2'
