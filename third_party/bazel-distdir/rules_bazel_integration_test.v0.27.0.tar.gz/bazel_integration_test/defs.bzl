"""Public API for rules_bazel_integration_test."""

load(
    "//bazel_integration_test/private:bazel_binaries.bzl",
    _bazel_binaries = "bazel_binaries",
)
load(
    "//bazel_integration_test/private:bazel_integration_test.bzl",
    _bazel_integration_test = "bazel_integration_test",
    _bazel_integration_tests = "bazel_integration_tests",
)
load(
    "//bazel_integration_test/private:default_test_runner.bzl",
    _default_test_runner = "default_test_runner",
)
load(
    "//bazel_integration_test/private:integration_test_utils.bzl",
    _integration_test_utils = "integration_test_utils",
)
load(
    "//bazel_integration_test/private:script_test.bzl",
    _script_test = "script_test",
)

# Macros
bazel_integration_test = _bazel_integration_test
bazel_integration_tests = _bazel_integration_tests
default_test_runner = _default_test_runner

# Repository Rules/Macros
bazel_binaries = _bazel_binaries

# APIs
integration_test_utils = _integration_test_utils

# Script tests
script_test = _script_test
