require('./package.json')
