module.exports = 42
