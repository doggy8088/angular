"Generated during release by release_prep.sh, using integrity.jq"

RELEASED_BINARY_INTEGRITY = {
  "unpack-aarch64-apple-darwin": "12502bad22e0725baeb37b531322fe1d12dd053ae6716bcead88cad5e26f0dab",
  "unpack-x86_64-apple-darwin": "ece7ac6f0a705ee97ca4b1bc724dfb3caf19c00ed29996a85df0443addbd2580",
  "venv-aarch64-apple-darwin": "951da9e74bac37bee5f2b876eed768a95af55183d1d9e6a5b5c6887ae3c9f7b2",
  "venv-x86_64-apple-darwin": "f04aa6dc00d2e88d823f617916efaf4259833777f7159d59a7daf6ea237de02b",
  "unpack-aarch64-unknown-linux-gnu": "48552e399a1f2ab97e62ca7fce5783b6214e284330c7555383f43acf82446636",
  "unpack-x86_64-unknown-linux-gnu": "fd265552bfd236efef519f81ce783322a50d8d7ab5af5d08a713e519cedff87f",
  "venv-aarch64-unknown-linux-gnu": "b05d6cbe485e8ed1872f330012929126778744208e47485d7e2be285a027c7ca",
  "venv-x86_64-unknown-linux-gnu": "61f53fe45da5f2f160907c87c1a2d663bc57eee667520a46490a837825be61c9"
}
