{
  w:: 'World',
  Hello: $.w,
}
