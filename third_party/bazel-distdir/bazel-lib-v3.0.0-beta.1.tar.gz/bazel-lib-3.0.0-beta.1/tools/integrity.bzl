"Generated during release by release_prep.sh, using integrity.jq"

RELEASED_BINARY_INTEGRITY = {
  "copy_directory-darwin_amd64": "dc4aab6542a7dea5ce72cc6408bd84e097b3e089172e6ede4178b7eabfe7ba1a",
  "copy_directory-darwin_arm64": "5e217079be0fce08ded166d53e758da16eb2ad4bd4aa8e8959877c580b885b3d",
  "copy_directory-freebsd_amd64": "6fef855e5851ee7affe2cbb34399301fc19e9bcc386e6d95b3e15d72d1c13f19",
  "copy_directory-linux_amd64": "3dd873ec94b542d890e4d66a224fae71c4bf04cea615a876c146c1602b58b108",
  "copy_directory-linux_arm64": "78eee94e25ca41e442c46e717d2c40bad5e27750bdff711944b6208b4a9e6269",
  "copy_directory-linux_s390x": "c05809a35c484496f1ef2d8d17aae97b0a898d42369f0c9119284f7a875956c6",
  "copy_directory-windows_amd64.exe": "079d50d865cbbac3c1aff493e95f851f3f7805743d0ae9c12cffbbed86883ad3",
  "copy_directory-windows_arm64.exe": "82812fd4f28f51ed7eb2241ee15f3a5e7fb613cff778e5bd4c5e32f16a806729",
  "copy_to_directory-darwin_amd64": "4036577494ecc8d14bfd73d96afbc5d680527361c34509ae4f864c4bade25c61",
  "copy_to_directory-darwin_arm64": "c36086f4afbfcdc44b7527c4149c5fba5e1af61809a1e43c9fec398c9f8ba208",
  "copy_to_directory-freebsd_amd64": "2166105e6189f70dab44f639b8343cc2eaa081b3fd63c882a84b532e72016036",
  "copy_to_directory-linux_amd64": "a1e99f85966f3c64f5c6934febcb30fc0991619d5e943702f6e6083c99e50dd9",
  "copy_to_directory-linux_arm64": "b9be7299fd53f50a164cf4f33f7c74db465858a152b564a4574a438c75094373",
  "copy_to_directory-linux_s390x": "a206326d1e8994deef6717e20d8c67bbd2fb396c9574df5a86a6fa1051106030",
  "copy_to_directory-windows_amd64.exe": "f36a598a19802d8e9f7c91043989225ce0acd7a33c0b7b6ead9e055e72992a3f",
  "copy_to_directory-windows_arm64.exe": "dbc6e74535a25b16dbdf45f85c5cbdf8dfc76471fc9707c060a6a76e846486da",
  "expand_template-darwin_amd64": "cf08c4c871792b928cfa01ec159fffab6f53b59535b294f402092e5723fab1e7",
  "expand_template-darwin_arm64": "b47a183694cc7e989864a4f52ea3c12fc2ab7345a4491302b40ce29e427a7d34",
  "expand_template-freebsd_amd64": "f4483d0536a6975d735b2236d453928a7a9366aa0a60b063bb32ca9e61ed77ef",
  "expand_template-linux_amd64": "b61fa64ee65fcb71a01515df401d59c83b82f27e0edd73f2e6972949095bc21e",
  "expand_template-linux_arm64": "46c00508d2fc7234950ef06e5cc027033542970e9e3067a988d643530a130caf",
  "expand_template-linux_s390x": "2b4602415fea0c199b31a51e2a60ced5f7f1ee7e17248c87b3338544317b750b",
  "expand_template-windows_amd64.exe": "611602999dc8cad36861760a49c97b544f102a4acd7b273adda1aa7c9ebd42df",
  "expand_template-windows_arm64.exe": "a438cc4efddfe12502408b6de00ac9dd4e1d6220a184cda0c9336a5d1fcf0e97"
}
