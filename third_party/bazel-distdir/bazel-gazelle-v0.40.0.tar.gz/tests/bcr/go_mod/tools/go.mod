module github.com/bazelbuild/bazel-gazelle/tests/bcr/go_mod/tools

go 1.21.0

require (
	github.com/99designs/gqlgen v0.17.40
	github.com/bazelbuild/buildtools v0.0.0-20231115204819-d4c9dccdfbb1
)

require (
	github.com/agnivade/levenshtein v1.1.1 // indirect
	github.com/cpuguy83/go-md2man/v2 v2.0.2 // indirect
	github.com/golang/protobuf v1.5.0 // indirect
	github.com/google/uuid v1.3.0 // indirect
	github.com/russross/blackfriday/v2 v2.1.0 // indirect
	github.com/sosodev/duration v1.1.0 // indirect
	github.com/urfave/cli/v2 v2.25.5 // indirect
	github.com/vektah/gqlparser/v2 v2.5.10 // indirect
	github.com/xrash/smetrics v0.0.0-20201216005158-039620a65673 // indirect
	golang.org/x/mod v0.10.0 // indirect
	golang.org/x/sys v0.8.0 // indirect
	golang.org/x/text v0.9.0 // indirect
	golang.org/x/tools v0.9.3 // indirect
	google.golang.org/protobuf v1.30.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
