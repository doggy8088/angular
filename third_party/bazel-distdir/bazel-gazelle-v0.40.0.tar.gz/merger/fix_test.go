/* Copyright 2022 The Bazel Authors. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package merger_test

import (
	"strings"
	"testing"

	"github.com/bazelbuild/bazel-gazelle/merger"
	"github.com/bazelbuild/bazel-gazelle/rule"
	bzl "github.com/bazelbuild/buildtools/build"
	"github.com/google/go-cmp/cmp"
)

func TestFixLoads(t *testing.T) {
	knownLoads := []rule.LoadInfo{
		{
			Name: "@bar",
			Symbols: []string{
				"magic_macro",
				"magic_struct",
			},
		},
		{
			Name: "@foo",
			Symbols: []string{
				"foo_binary",
				"foo_library",
			},
		},
		{
			Name: "@foo",
			Symbols: []string{
				"foo_test",
			},
		},
		{
			Name: "@bazel_tools//tools/build_defs/repo:utils.bzl",
			Symbols: []string{
				"maybe",
			},
		},
		{
			Name: "@bazel_skylib//lib:selects.bzl",
			Symbols: []string{
				"selects",
			},
		},
	}

	type testCase struct {
		input string
		want  string
	}

	for name, tc := range map[string]testCase{
		"correct": {
			input: `load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
			want: `load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
		},
		"correct with macro": {
			input: `load("@bar", "magic_macro")
load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(
	name = "a_lib",
	deps = [
		"//a/b:c",
		magic_macro("baz"),
	],
)
		`,
			want: `load("@bar", "magic_macro")
load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(
    name = "a_lib",
    deps = [
        "//a/b:c",
        magic_macro("baz"),
    ],
)
`,
		},
		"missing macro load": {
			input: `load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(
    name = "a_lib",
    deps = [
        "//a/b:c",
        magic_macro("baz"),
    ],
)
`,
			want: `load("@bar", "magic_macro")
load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(
    name = "a_lib",
    deps = [
        "//a/b:c",
        magic_macro("baz"),
    ],
)
`,
		},
		"unused macro": {
			input: `load("@bar", "magic_macro")
			load("@foo", "foo_binary")

foo_binary(name = "a")
`,
			want: `load("@foo", "foo_binary")

foo_binary(name = "a")
`,
		},
		"missing kind load symbol": {
			input: `load("@foo", "foo_binary")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
			want: `load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
		},
		"missing kind load": {
			input: `foo_binary(name = "a")

foo_library(name = "a_lib")
`,
			want: `load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
		},
		"missing wrapper and wrapped kind load symbol": {
			input: `maybe(
    foo_binary,
    name = "a",
)
`,
			want: `load("@foo", "foo_binary")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    foo_binary,
    name = "a",
)
`,
		},
		"unused kind load symbol": {
			input: `load("@foo", "foo_binary", "foo_library", "foo_test")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
			want: `load("@foo", "foo_binary", "foo_library")

foo_binary(name = "a")

foo_library(name = "a_lib")
`,
		},
		"struct macro": {
			input: `selects.config_setting_group(
    name = "a",
    match_any = [
        "//:config_a",
        "//:config_b",
    ],
)
`,
			want: `load("@bazel_skylib//lib:selects.bzl", "selects")

selects.config_setting_group(
    name = "a",
    match_any = [
        "//:config_a",
        "//:config_b",
    ],
)
`,
		},
		"struct member": {
			input: `foo_binary(
    name = "a",
    field = magic_struct.member,
)
`,
			want: `load("@bar", "magic_struct")
load("@foo", "foo_binary")

foo_binary(
    name = "a",
    field = magic_struct.member,
)
`,
		},
	} {
		t.Run(name, func(t *testing.T) {
			f, err := rule.LoadData("", "", []byte(tc.input))
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}

			merger.FixLoads(f, knownLoads)
			f.Sync()

			want := strings.TrimSpace(tc.want)
			got := strings.TrimSpace(string(bzl.FormatWithoutRewriting(f.File)))
			if diff := cmp.Diff(want, got); diff != "" {
				t.Errorf("FixLoads() mismatch (-want +got):\n%s", diff)
			}
		})
	}
}
