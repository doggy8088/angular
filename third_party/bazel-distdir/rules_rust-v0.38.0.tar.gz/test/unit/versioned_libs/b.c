void hello(void) {}
