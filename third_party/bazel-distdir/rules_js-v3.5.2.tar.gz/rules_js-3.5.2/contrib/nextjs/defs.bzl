"""Utilities for building Next.js applications with Bazel and rules_js.

All invocations of Next.js are done through a `next_js_binary` target passed into the macros.
This is normally generated once alongside the `package.json` containing the `next` dependency:

```
load("@npm//:next/package_json.bzl", next_bin = "bin")

next_bin.next_binary(
    name = "next_js_binary",
    visibility = ["//visibility:public"],
)
```

The next binary is then passed into the macros, for example:

```
nextjs_build(
    name = "next",
    config = "next.config.mjs",
    srcs = glob(["src/**"]),
    next_js_binary = "//:next_js_binary",
)
```

There are two sets of macros for building Next.js applications: standard and standalone.

### Standard Build

- `nextjs()`: wrap the build+dev+start targets
- `nextjs_build()`: the Next.js [build](https://nextjs.org/docs/app/building-your-application/deploying#production-builds) command
- `nextjs_dev()`: the Next.js [dev](https://nextjs.org/docs/app/getting-started/installation#run-the-development-server) command
- `nextjs_start()`: the Next.js [start](https://nextjs.org/docs/app/building-your-application/deploying#nodejs-server) command,
   accepting a Next.js build artifact to start

### Standalone Mode

For [standalone applications](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files):
- `nextjs_standalone_build()`: the Next.js [build](https://nextjs.org/docs/app/building-your-application/deploying#production-builds) command,
   configured for a standalone application within bazel
- `nextjs_standalone_server()`: constructs a standalone Next.js server `js_binary` following the
  [standalone directory structure guidelines](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files)
"""

load("@bazel_lib//lib:copy_directory.bzl", "copy_directory_bin_action")
load("@bazel_lib//lib:copy_file.bzl", "copy_file")
load("@bazel_lib//lib:copy_to_directory.bzl", "copy_to_directory")
load("@bazel_lib//lib:directory_path.bzl", "directory_path")
load("//js:defs.bzl", "js_binary", "js_run_binary", "js_run_devserver")

# The Next.js output directory which is not configurable
_next_build_out = ".next"

# The Next.js config file which is not configurable (other then file extension).
_next_build_config = "next.config.mjs"

# A label to the rules_js/contrib config file.
_next_standalone_config = Label("next.bazel.mjs")

def nextjs(
        name,
        srcs,
        next_js_binary,
        config = "next.config.mjs",
        data = [],
        serve_data = [],
        **kwargs):
    """Generates Next.js build, dev & start targets.

    `{name}`       - a Next.js production bundle
    `{name}.dev`   - a Next.js devserver
    `{name}.start` - a Next.js prodserver

    Use this macro in the BUILD file at the root of a next app where the `next.config.mjs`
    file is located.

    For example, a target such as `//app:next` in `app/BUILD.bazel`

    ```
    next(
        name = "next",
        config = "next.config.mjs",
        srcs = glob(["src/**"]),
        data = [
            "//:node_modules/next",
            "//:node_modules/react-dom",
            "//:node_modules/react",
            "package.json",
        ],
        next_js_binary = "//:next_js_binary",
    )
    ```

    will create the targets:

    ```
    //app:next
    //app:next.dev
    //app:next.start
    ```

    To build the above next app, equivalent to running `next build` outside Bazel:

    ```
    bazel build //app:next
    ```

    To run the development server in watch mode with
    [ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
    `next dev` outside Bazel:

    ```
    ibazel run //app:next.dev
    ```

    To run the production server in watch mode with
    [ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
    `next start` outside Bazel:

    ```
    ibazel run //app:next.start
    ```

    Args:
        name: the name of the build target

        config: the Next.js config file. Typically `next.config.mjs`.

        srcs: Source files to include in build & dev targets.
            Typically these are source files or transpiled source files in Next.js source folders
            such as `pages`, `public` & `styles`.

        data: Data files to include in all targets.
            These are typically npm packages required for the build & configuration files such as
            package.json and next.config.js.

        serve_data: Data files to include in devserver targets

        next_js_binary: The next `js_binary` target to use for running Next.js

            Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
            file of the npm package.

            See main docstring above for example usage.

        **kwargs: Other attributes passed to all targets such as `tags`.
    """

    nextjs_build(
        name = name,
        config = config,
        srcs = srcs,
        next_js_binary = next_js_binary,
        data = data,
        **kwargs
    )
    nextjs_dev(
        name = name + ".dev",
        config = config,
        srcs = srcs,
        data = data + serve_data,
        next_js_binary = next_js_binary,
        **kwargs
    )
    nextjs_start(
        name = name + ".start",
        config = config,
        app = ":{}".format(name),
        next_js_binary = next_js_binary,
        # NOTE: must include `srcs` in addition to the pre-compiled `app` to include transitive
        # deps such as npm packages, including the core Next.js and react packages. Could possibly
        # remove source files and only include transitive deps.
        data = data + srcs + serve_data,
        **kwargs
    )

def nextjs_build(name, config, srcs, next_js_binary, data = [], use_execroot_entry_point = True, args = [], **kwargs):
    """Build the Next.js production artifact.

    See https://nextjs.org/docs/pages/api-reference/cli/next#build

    Args:
        name: the name of the build target
        config: the Next.js config file
        srcs: the sources to include in the build, including any transitive deps
        data: the data files to include in the build

        next_js_binary: The next `js_binary` target to use for running Next.js

            Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
            file of the npm package.

            See main docstring above for example usage.

        use_execroot_entry_point: passed directly to js_run_binary

        args: Additional arguments to pass to `next build`, appended after the
            `build` subcommand. For example `["--webpack"]` to opt out of
            Turbopack, which cannot run under a Bazel sandbox.

            The `build` subcommand itself is not overridable.

        **kwargs: Other attributes passed to all targets such as `tags`, env
    """
    js_run_binary(
        name = name,
        tool = next_js_binary,
        args = ["build"] + args,
        srcs = srcs + data + [config],
        out_dirs = [_next_build_out],
        chdir = native.package_name(),
        mnemonic = "NextJs",
        progress_message = "Compile Next.js app %{label}",
        use_execroot_entry_point = use_execroot_entry_point,
        **kwargs
    )

def nextjs_start(name, config, app, next_js_binary, data = [], **kwargs):
    """Run the Next.js production server for an app.

    See https://nextjs.org/docs/pages/api-reference/cli/next#next-start-options

    Args:
        name: the name of the build target
        config: the Next.js config file
        app: the pre-compiled Next.js application, typically the output of `nextjs_build`
        data: additional server data

        next_js_binary: The next `js_binary` target to use for running Next.js

            Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
            file of the npm package.

            See main docstring above for example usage.

        **kwargs: Other attributes passed to all targets such as `tags`, env
    """

    js_run_devserver(
        name = name,
        tool = next_js_binary,
        args = ["start"],
        data = data + [app, config],
        chdir = native.package_name(),
        **kwargs
    )

def nextjs_dev(name, config, srcs, data, next_js_binary, **kwargs):
    """Run the Next.js development server.

    See https://nextjs.org/docs/pages/api-reference/cli/next#next-dev-options

    Args:
        name: the name of the build target
        config: the Next.js config file
        srcs: the sources to include in the build, including any transitive deps
        data: additional devserver runtime data

        next_js_binary: The next `js_binary` target to use for running Next.js

            Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
            file of the npm package.

            See main docstring above for example usage.

        **kwargs: Other attributes passed to all targets such as `tags`, env
    """
    js_run_devserver(
        name = name,
        tool = next_js_binary,
        args = ["dev"],
        data = srcs + data + [config],
        chdir = native.package_name(),
        **kwargs
    )

# ---------------------------------------------------------------------------------------------
# Standalone Next.js build & server binary.
# ---------------------------------------------------------------------------------------------

def nextjs_standalone_build(name, config, srcs, next_js_binary, data = [], use_execroot_entry_point = True, args = [], **kwargs):
    """Compile a standalone Next.js application.

    See https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files

    NOTE: a `next.config.mjs` is generated, wrapping the passed `config`, to overcome Next.js limitation with bazel,
    rules_js and pnpm (with hoist=false, as required by rules_js).

    The `config` file is renamed and dynamically imported by the generated `next.config.mjs`. Including the `config` file
    elsewhere (e.g. in `srcs` or `data`) may cause issues, particularly if it follows Next.js naming conventions
    and is loaded by Next.js instead of the generated `next.config.mjs`.

    Issues worked around by the generated config include:
    * https://github.com/vercel/next.js/issues/48017
    * https://github.com/aspect-build/rules_js/issues/714

    Args:
        name: the name of the build target
        config: the Next.js config file
        srcs: the sources to include in the build, including any transitive deps
        next_js_binary: the Next.js binary to use for building
        data: the data files to include in the build
        use_execroot_entry_point: passed directly to js_run_binary

        args: Additional arguments to pass to `next build`, appended after the
            `build` subcommand. For example `["--webpack"]` to opt out of
            Turbopack, which cannot run under a Bazel sandbox.

            The `build` subcommand itself is not overridable.

        **kwargs: Other attributes passed to all targets such as `tags`, env
    """

    tags = kwargs.pop("tags", [])
    testonly = kwargs.pop("testonly", False)
    visibility = kwargs.pop("visibility", [])

    # Extract the basename from config, which may be a label like ":next.config.js"
    # or "//pkg:next.config.js". The copy_file `out` must be a plain filename.
    config_basename = config.split(":")[-1].split("/")[-1]

    copy_file(
        name = "_%s.original_config_file" % name,
        src = config,
        out = "__original.%s" % config_basename,
        visibility = ["//visibility:private"],
        tags = tags + ["manual"],
        testonly = testonly,
    )

    # Wrap the config file to add necessary bazel logic
    env = kwargs.pop("env", {})
    env["NEXTJS_STANDALONE_CONFIG"] = "$(locations :_%s.original_config_file)" % name
    copy_file(
        name = "_%s.standalone_config_file" % name,
        src = _next_standalone_config,
        out = _next_build_config,
        visibility = ["//visibility:private"],
        tags = tags + ["manual"],
        testonly = testonly,
    )

    # `next build` of the standalone application.
    # Next.js is tricky to handle in Bazel, because during its pre-rendering it
    # executes some of the sources it is operating on. We run the risk of
    # either trying to run code for an incompatible platform, or mixing
    # node_modules directories from two different platforms. We work around
    # these issues by building for the exec platform and then copying that
    # result verbatim to the target platform bin directory.
    js_run_binary(
        name = "_%s.next_build" % name,
        tool = next_js_binary,
        env = env,
        args = ["build"] + args,
        srcs = srcs + data + [":_%s.standalone_config_file" % name, ":_%s.original_config_file" % name],
        out_dirs = [_next_build_out],
        chdir = native.package_name(),
        mnemonic = "NextJs",
        progress_message = "Compile Next.js standalone app %{label}",
        use_execroot_entry_point = use_execroot_entry_point,
        tags = tags + ["manual"],
        testonly = testonly,
        visibility = ["//visibility:private"],
        **kwargs
    )

    _copy_exec_to_bin(
        name = name,
        src = "_%s.next_build" % name,
        tags = tags,
        testonly = testonly,
        visibility = visibility,
    )

def nextjs_standalone_server(name, app, pkg = None, data = [], **kwargs):
    """Configures the output of a standalone Next.js application to be a standalone server binary.

    See the Next.js [standalone server documentation](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files)
    for details on the standalone server directory structure.

    This function is normally used in conjunction with `nextjs_standalone_build` to create a standalone
    Next.js application. The standalone server is a `js_binary` target that can be run with `bazel run`
    or deployed in a container image etc.

    Args:
        name: the name of the binary target

        app: the standalone app directory, typically the output of `nextjs_standalone_build`

        pkg: the directory server.js is in within the standalone/ directory.

            This is normally the application path relative to the pnpm-lock.yaml.

            Default: native.package_name() (for a pnpm-lock.yaml in the root of the workspace)

        data: runtime data required to run the standalone server.

            Normally requires `[":node_modules/next", ":node_modules/react"]` which are not included
            in the Next.js standalone output.

        **kwargs: additional `js_binary` attributes
    """

    # The output directory containing the standalone application.
    standalone_outdir = name

    if pkg == None:
        pkg = native.package_name()

    # The `app` tree artifact (from `nextjs_standalone_build`) exposes its files under a directory
    # named after the build target rather than under a `.next/` prefix. `nextjs_standalone_build`
    # runs `next build` (which writes to `.next`) and then copies that tree into a directory named
    # after the build target via `_copy_exec_to_bin` (it cannot reuse `.next`, which is already
    # owned by the build action). So a build target `:foo` yields paths like `foo/standalone/...`,
    # `foo/static/...`. Derive that prefix from the `app` label to match the actual layout.
    #
    # Strip only the package portion (everything up to and including the last `:`); Bazel target
    # names may legitimately contain slashes (e.g. `:web/next`), and those slashes are part of the
    # directory name, so they must be preserved.
    app_dir = app.split(":")[-1] if ":" in app else app.split("/")[-1]

    # The server entry point into the standalone directory.
    directory_path(
        name = "_{}.js".format(name),
        directory = ":_{}.standalone".format(name),
        path = "standalone/{}/server.js".format(pkg),
        visibility = ["//visibility:private"],
        tags = ["manual"],
    )

    # Copy the standalone directory and public/static to create a standalone server.
    # See https://nextjs.org/docs/pages/api-reference/config/next-config-js/output#automatically-copying-traced-files
    copy_to_directory(
        name = "_{}.standalone".format(name),
        srcs = [app] + native.glob(["public/**"]),
        include_srcs_patterns = [
            "public/**",
            "{}/static/**".format(app_dir),
            "{}/standalone/**".format(app_dir),
        ],
        exclude_srcs_patterns = [
            # TODO: exclude non-deterministic and log/trace files?
        ],
        replace_prefixes = {
            "{}/standalone".format(app_dir): "standalone",
            "{}/static".format(app_dir): "standalone/{}/{}/static".format(pkg, _next_build_out),
            "public": "standalone/{}/public".format(pkg),
        },
        out = standalone_outdir,
        allow_overwrites = True,
        visibility = ["//visibility:private"],
        tags = ["manual"],
    )

    # The standalone server binary
    js_binary(
        name = name,
        entry_point = ":_{}.js".format(name),
        chdir = native.package_name(),
        data = data + ["_{}.standalone".format(name)],
        **kwargs
    )

def _copy_exec_to_bin_impl(ctx):
    dst = ctx.actions.declare_directory(ctx.label.name)
    copy_directory_bin = ctx.toolchains["@bazel_lib//lib:copy_directory_toolchain_type"].copy_directory_info.bin
    copy_directory_bin_action(
        ctx,
        src = ctx.file.src,
        dst = dst,
        copy_directory_bin = copy_directory_bin,
    )
    return [
        DefaultInfo(
            files = depset([dst]),
            runfiles = ctx.runfiles([dst]),
        ),
    ]

_copy_exec_to_bin = rule(
    implementation = _copy_exec_to_bin_impl,
    attrs = {
        "src": attr.label(
            mandatory = True,
            allow_single_file = True,
            cfg = "exec",
            doc = "A tree-artifact target to copy from exec-platform to target-platform bin.",
        ),
    },
    toolchains = ["@bazel_lib//lib:copy_directory_toolchain_type"],
    doc = "Copies a tree artifact built in the exec configuration into the target-platform bin directory.",
)
