/**
 * @license
 * Copyright 2019 The Bazel Authors. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert'
import * as fs from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { withFixtures } from 'inline-fixtures'
import * as path from 'node:path'
import * as util from 'node:util'

import { patcher } from '../../node-bootstrap/src/fs.cjs'
import { describe, it } from './harness.cjs'

describe('testing readlink', async () => {
    await it('can resolve symlink in root', async () => {
        await withFixtures(
            {
                a: {},
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                // create symlink from a to b
                fs.symlinkSync(
                    path.join(fixturesDir, 'b', 'file'),
                    path.join(fixturesDir, 'a', 'link')
                )

                const revertPatches = patcher([path.join(fixturesDir)])

                const linkPath = path.join(fixturesDir, 'a', 'link')

                assert.deepStrictEqual(
                    fs.readlinkSync(linkPath),
                    path.join(fixturesDir, 'b', 'file'),
                    'SYNC: should read the symlink because its within root'
                )

                assert.deepStrictEqual(
                    fs.readlinkSync(new URL(`file://${linkPath}`)),
                    path.join(fixturesDir, 'b', 'file'),
                    'SYNC: should read the symlink because its within root'
                )

                assert.deepStrictEqual(
                    await util.promisify(fs.readlink)(
                        new URL(`file://${linkPath}`)
                    ),
                    path.join(fixturesDir, 'b', 'file'),
                    'CB: should read the symlink because its within root'
                )

                assert.deepStrictEqual(
                    await util.promisify(fs.readlink)(linkPath),
                    path.join(fixturesDir, 'b', 'file'),
                    'CB: should read the symlink because its within root'
                )

                assert.deepStrictEqual(
                    await fs.promises.readlink(linkPath),
                    path.join(fixturesDir, 'b', 'file'),
                    'Promise: should read the symlink because its within root'
                )

                revertPatches()
            }
        )
    })

    await it('preserves relative symlink targets in root', async () => {
        await withFixtures(
            {
                a: {},
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                const linkPath = path.join(fixturesDir, 'a', 'link')
                const relativeTarget = path.join('..', 'b', 'file')

                fs.symlinkSync(relativeTarget, linkPath)

                const revertPatches = patcher([path.join(fixturesDir)])

                assert.deepStrictEqual(
                    fs.readlinkSync(linkPath),
                    relativeTarget,
                    'SYNC: should preserve relative symlink target'
                )

                assert.deepStrictEqual(
                    await util.promisify(fs.readlink)(linkPath),
                    relativeTarget,
                    'CB: should preserve relative symlink target'
                )

                assert.deepStrictEqual(
                    await fs.promises.readlink(linkPath),
                    relativeTarget,
                    'Promise: should preserve relative symlink target'
                )

                revertPatches()
            }
        )
    })

    await it('preserves relative targets when the root is a symlink', async () => {
        await withFixtures(
            {
                realroot: {
                    a: {},
                    b: { file: 'contents' },
                },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                const realRoot = path.join(fixturesDir, 'realroot')
                const rootLink = path.join(fixturesDir, 'rootlink')
                const relativeTarget = path.join('..', 'b', 'file')

                fs.symlinkSync(
                    realRoot,
                    rootLink,
                    process.platform === 'win32' ? 'junction' : 'dir'
                )
                fs.symlinkSync(
                    relativeTarget,
                    path.join(realRoot, 'a', 'link')
                )

                const revertPatches = patcher([rootLink])
                const linkPath = path.join(rootLink, 'a', 'link')

                try {
                    assert.deepStrictEqual(
                        fs.readlinkSync(linkPath),
                        relativeTarget,
                        'SYNC: should preserve target within a symlinked root'
                    )

                    assert.deepStrictEqual(
                        await util.promisify(fs.readlink)(linkPath),
                        relativeTarget,
                        'CB: should preserve target within a symlinked root'
                    )

                    assert.deepStrictEqual(
                        await fs.promises.readlink(linkPath),
                        relativeTarget,
                        'Promise: should preserve target within a symlinked root'
                    )
                } finally {
                    revertPatches()
                }
            }
        )
    })

    await it('resolves relative targets from the real parent of an aliased path', async () => {
        await withFixtures(
            {
                execroot: { package: {} },
                real: { file: 'contents' },
                sandbox: { aliases: { real: {} } },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                const execrootDir = path.join(fixturesDir, 'execroot')
                const realFile = path.join(fixturesDir, 'real', 'file')
                const sandboxDir = path.join(fixturesDir, 'sandbox')
                const aliasDir = path.join(sandboxDir, 'aliases', 'package')

                // The queried parent has one more path segment than its real
                // location, so resolving ../target from the lexical parent
                // incorrectly lands at sandbox/aliases/target.
                fs.symlinkSync(
                    path.join(execrootDir, 'package'),
                    aliasDir,
                    process.platform === 'win32' ? 'junction' : 'dir'
                )
                fs.symlinkSync(
                    path.join('..', 'target'),
                    path.join(execrootDir, 'package', 'link')
                )
                fs.symlinkSync(realFile, path.join(execrootDir, 'target'))
                fs.symlinkSync(
                    realFile,
                    path.join(sandboxDir, 'aliases', 'real', 'file')
                )

                const revertPatches = patcher([sandboxDir])
                const linkPath = path.join(aliasDir, 'link')
                const expectedTarget = path.join('..', 'real', 'file')

                try {
                    assert.deepStrictEqual(
                        fs.readlinkSync(linkPath),
                        expectedTarget,
                        'SYNC: should resolve from the real parent directory'
                    )

                    assert.deepStrictEqual(
                        await util.promisify(fs.readlink)(linkPath),
                        expectedTarget,
                        'CB: should resolve from the real parent directory'
                    )

                    assert.deepStrictEqual(
                        await fs.promises.readlink(linkPath),
                        expectedTarget,
                        'Promise: should resolve from the real parent directory'
                    )
                } finally {
                    revertPatches()
                }
            }
        )
    })

    await it("doesn't resolve as symlink outside of root", async () => {
        await withFixtures(
            {
                a: {},
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                // create symlink from a to b
                fs.symlinkSync(
                    path.join(fixturesDir, 'b', 'file'),
                    path.join(fixturesDir, 'a', 'link')
                )

                const revertPatches = patcher([path.join(fixturesDir, 'a')])

                const linkPath = path.join(
                    fs.realpathSync(fixturesDir),
                    'a',
                    'link'
                )

                assert.throws(() => {
                    fs.readlinkSync(linkPath)
                }, "should throw because it's not a link")

                let thrown
                try {
                    await util.promisify(fs.readlink)(linkPath)
                } catch (e) {
                    thrown = e
                } finally {
                    if (!thrown) assert.fail('must throw einval error')
                }

                thrown = undefined
                try {
                    await fs.promises.readlink(linkPath)
                } catch (e) {
                    thrown = e
                } finally {
                    if (!thrown) assert.fail('must throw einval error')
                }

                revertPatches()
            }
        )
    })

    await it('can resolve symlink to a symlink in the sandbox if it has a corresponding location', async () => {
        await withFixtures(
            {
                sandbox: {},
                execroot: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)

                // create symlink from execroot/link to execroot/file
                fs.symlinkSync(
                    path.join(fixturesDir, 'execroot', 'file'),
                    path.join(fixturesDir, 'execroot', 'link')
                )

                // create sandbox
                fs.symlinkSync(
                    path.join(fixturesDir, 'execroot', 'file'),
                    path.join(fixturesDir, 'sandbox', 'file')
                )
                fs.symlinkSync(
                    path.join(fixturesDir, 'execroot', 'link'),
                    path.join(fixturesDir, 'sandbox', 'link')
                )

                const revertPatches = patcher([
                    path.join(fixturesDir, 'sandbox'),
                ])
                const linkPath = path.join(fixturesDir, 'sandbox', 'link')
                const filePath = path.join(fixturesDir, 'sandbox', 'file')

                assert.deepStrictEqual(
                    fs.readlinkSync(linkPath),
                    filePath,
                    'SYNC: should read the symlink in the sandbox'
                )

                assert.deepStrictEqual(
                    fs.readlinkSync(new URL(`file://${linkPath}`)),
                    filePath,
                    'SYNC: should read the symlink in the sandbox'
                )

                assert.deepStrictEqual(
                    await util.promisify(fs.readlink)(
                        new URL(`file://${linkPath}`)
                    ),
                    filePath,
                    'CB: should read the symlink in the sandbox'
                )

                assert.deepStrictEqual(
                    await util.promisify(fs.readlink)(linkPath),
                    filePath,
                    'CB: should read the symlink in the sandbox'
                )

                assert.deepStrictEqual(
                    await fs.promises.readlink(linkPath),
                    filePath,
                    'Promise: should read the symlink in the sandbox'
                )

                revertPatches()
            }
        )
    })

    await it('cant resolve symlink to a symlink in the sandbox if it has no corresponding location', async () => {
        await withFixtures(
            {
                sandbox: {},
                execroot: {},
                otherroot: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)

                // create dangling symlink from execroot/link to execroot/file
                fs.symlinkSync(
                    path.join(fixturesDir, 'otherroot', 'file'),
                    path.join(fixturesDir, 'execroot', 'link')
                )
                // create sandbox
                fs.symlinkSync(
                    path.join(fixturesDir, 'execroot', 'link'),
                    path.join(fixturesDir, 'sandbox', 'link')
                )

                const revertPatches = patcher([
                    path.join(fixturesDir, 'sandbox'),
                ])

                const linkPath = path.join(fixturesDir, 'sandbox', 'link')
                const filePath = path.join(fixturesDir, 'sandbox', 'file')

                assert.throws(() => {
                    fs.readlinkSync(linkPath)
                }, "should throw because it's not a resolvable link")

                let thrown
                try {
                    await util.promisify(fs.readlink)(linkPath)
                } catch (e) {
                    thrown = e
                } finally {
                    if (!thrown) assert.fail('must throw einval error')
                }

                thrown = undefined
                try {
                    await fs.promises.readlink(linkPath)
                } catch (e) {
                    thrown = e
                } finally {
                    if (!thrown) assert.fail('must throw einval error')
                }

                revertPatches()
            }
        )
    })

    await it('handles parent renames through asynchronous APIs', async () => {
        await withFixtures({ parent: {}, file: 'contents' }, async (root) => {
            root = fs.realpathSync(root)
            const parent = path.join(root, 'parent')
            const moved = path.join(root, 'moved')
            const link = path.join(parent, 'link')
            fs.symlinkSync('../file', link)
            const { default: mutableFs } = await import('node:fs')
            const nativeReadlink = mutableFs.readlink
            mutableFs.readlink = (...args) => {
                const callback = args.pop()
                nativeReadlink(...args, (error, target) => {
                    // Remove the parent after native readlink succeeds but before
                    // the guard resolves the relative target against that parent.
                    if (!error) fs.renameSync(parent, moved)
                    callback(error, target)
                })
            }
            const revert = patcher([root])
            try {
                for (const method of [
                    util.promisify(fs.readlink),
                    fs.promises.readlink,
                ]) {
                    await assert.rejects(method(link), { code: 'ENOENT' })
                    fs.renameSync(moved, parent)
                }
                for (const method of [
                    util.promisify(fs.lstat),
                    fs.promises.lstat,
                ]) {
                    assert.ok((await method(link)).isSymbolicLink())
                    fs.renameSync(moved, parent)
                }
                fs.unlinkSync(link)
                fs.symlinkSync(path.join(root, 'file'), link)
                for (const method of [
                    util.promisify(fs.readlink),
                    fs.promises.readlink,
                ]) {
                    assert.equal(await method(link), path.join(root, 'file'))
                    fs.renameSync(moved, parent)
                }
            } finally {
                revert()
                mutableFs.readlink = nativeReadlink
                syncBuiltinESMExports()
            }
        })
    })

    await it('includes parent calls in stack traces', async function readlinkStackTest1() {
        let err
        try {
            fs.readlinkSync(null)
        } catch (e) {
            err = e
        } finally {
            if (!err) assert.fail('readlinkSync should fail on invalid path')
            if (!err.stack.includes('readlinkStackTest1'))
                assert.fail(
                    `readlinkSync error stack should contain calling method: ${err.stack}`
                )
        }
    })
})
