/**
 * @license
 * Copyright 2019 The Bazel Authors. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as assert from 'node:assert'
import * as fs from 'node:fs'
import { withFixtures } from 'inline-fixtures'
import * as path from 'node:path'
import * as util from 'node:util'

import { patcher } from '../../node-bootstrap/src/fs.cjs'
import { describe, it } from './harness.cjs'

describe('testing lstat', async () => {
    await it('can lstat symlink in root', async () => {
        await withFixtures(
            {
                a: {},
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                // create symlink from a/link to b/file
                fs.symlinkSync(
                    path.join(fixturesDir, 'b', 'file'),
                    path.join(fixturesDir, 'a', 'link')
                )

                const revertPatches = patcher([path.join(fixturesDir)])

                const linkPath = path.join(fixturesDir, 'a', 'link')
                assert.ok(
                    fs.lstatSync(linkPath).isSymbolicLink(),
                    'lstatSync should find symbolic link if link is the root'
                )

                assert.ok(
                    (await util.promisify(fs.lstat)(linkPath)).isSymbolicLink(),
                    'lstat should find symbolic link if link is the root'
                )

                assert.ok(
                    (await fs.promises.lstat(linkPath)).isSymbolicLink(),
                    'promises.lstat should find symbolic link if link is the root'
                )

                revertPatches()
            }
        )
    })

    await it('hides escaping file links reached through directory aliases', async () => {
        await withFixtures(
            {
                sandbox: { packages: { pkg: {} }, node_modules: {} },
                'package.json': '{"name":"fixture"}',
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                const root = path.join(fixturesDir, 'sandbox')
                fs.symlinkSync(
                    path.join(fixturesDir, 'package.json'),
                    path.join(root, 'packages/pkg/package.json')
                )
                fs.symlinkSync(
                    '../packages/pkg',
                    path.join(root, 'node_modules/pkg'),
                    'dir'
                )
                const file = path.join(root, 'node_modules/pkg/package.json')
                const revertPatches = patcher([root])
                try {
                    for (const stats of [
                        fs.lstatSync(file, { bigint: true }),
                        await util.promisify(fs.lstat)(file, { bigint: true }),
                        await fs.promises.lstat(file, { bigint: true }),
                    ]) {
                        assert.ok(stats.isFile())
                        assert.equal(typeof stats.size, 'bigint')
                    }
                    assert.throws(() => fs.readlinkSync(file), {
                        code: 'EINVAL',
                    })
                    await assert.rejects(util.promisify(fs.readlink)(file), {
                        code: 'EINVAL',
                    })
                    await assert.rejects(fs.promises.readlink(file), {
                        code: 'EINVAL',
                    })
                } finally {
                    revertPatches()
                }
            }
        )
    })

    await it('classifies file links through nested relative directory aliases', async () => {
        await withFixtures(
            {
                sandbox: {
                    packages: { group: { pkg: {}, other: {} } },
                    node_modules: {},
                    local: 'inside',
                },
                outside: 'outside',
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                const root = path.join(fixturesDir, 'sandbox')
                const pkg = path.join(root, 'packages/group/pkg')
                const other = path.join(root, 'packages/group/other')
                fs.symlinkSync(
                    '../packages/group/pkg',
                    path.join(root, 'node_modules/pkg'),
                    'dir'
                )
                fs.symlinkSync('../other', path.join(pkg, 'sub'), 'dir')
                fs.symlinkSync('../../../local', path.join(other, 'visible'))
                fs.symlinkSync(
                    '../../../../outside',
                    path.join(other, 'hidden')
                )
                const revertPatches = patcher([root])
                try {
                    for (const [leaf, visible] of [
                        ['visible', true],
                        ['hidden', false],
                    ]) {
                        const file = path.join(
                            root,
                            'node_modules/pkg/sub',
                            leaf
                        )
                        for (const stats of [
                            fs.lstatSync(file),
                            await util.promisify(fs.lstat)(file),
                            await fs.promises.lstat(file),
                        ]) {
                            assert.equal(stats.isSymbolicLink(), visible, leaf)
                            assert.equal(stats.isFile(), !visible, leaf)
                        }
                    }
                } finally {
                    revertPatches()
                }
            }
        )
    })

    await it('only exposes remapped links that lead to the original target', async () => {
        await withFixtures(
            {
                sandbox: {
                    absent: {},
                    unrelated: {},
                    corresponding: {},
                    aliased: {},
                },
                outside: { payload: 'correct' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                fs.symlinkSync(
                    'payload',
                    path.join(fixturesDir, 'outside/chain')
                )
                for (const kind of [
                    'absent',
                    'unrelated',
                    'corresponding',
                    'aliased',
                ]) {
                    let root = path.join(fixturesDir, 'sandbox', kind)
                    if (kind === 'aliased') {
                        // The guard's lexical and physical parents differ in depth.
                        const alias = path.join(fixturesDir, 'alias')
                        fs.symlinkSync(root, alias, 'dir')
                        root = alias
                    }
                    const file = path.join(root, 'entry')
                    fs.symlinkSync('../../outside/chain', file)
                    if (kind === 'unrelated') {
                        fs.writeFileSync(path.join(root, 'payload'), 'wrong')
                    } else if (kind === 'corresponding') {
                        fs.symlinkSync(
                            '../../outside/payload',
                            path.join(root, 'payload')
                        )
                    }
                    const revertPatches = patcher([root])
                    try {
                        for (const stats of [
                            fs.lstatSync(file),
                            await util.promisify(fs.lstat)(file),
                            await fs.promises.lstat(file),
                        ]) {
                            assert.equal(
                                stats.isSymbolicLink(),
                                kind === 'corresponding'
                            )
                            const target = stats.isSymbolicLink()
                                ? path.resolve(root, fs.readlinkSync(file))
                                : file
                            assert.equal(
                                fs.readFileSync(target, 'utf8'),
                                'correct'
                            )
                        }
                    } finally {
                        revertPatches()
                    }
                }
            }
        )
    })

    await it('can lstatSync throwIfNoEntry:false', async () => {
        await withFixtures(
            {
                a: { g: {} },
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)

                const revertPatches = patcher([
                    path.join(fixturesDir),
                    path.join(fixturesDir, 'a', 'g'),
                ])

                assert.equal(
                    undefined,
                    fs.lstatSync(path.join(fixturesDir, 'doesnt-exist'), {
                        throwIfNoEntry: false,
                    })
                )

                revertPatches()
            }
        )
    })

    await it('can lstat symlink in guard is file', async () => {
        await withFixtures(
            {
                a: { g: {} },
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                // create symlink from a/g/link to b/file
                fs.symlinkSync(
                    path.join(fixturesDir, 'b', 'file'),
                    path.join(fixturesDir, 'a', 'g', 'link')
                )

                const revertPatches = patcher([
                    path.join(fixturesDir),
                    path.join(fixturesDir, 'a', 'g'),
                ])

                console.error('Starting')
                console.error(fs.readlink.toString())

                const linkPath = path.join(fixturesDir, 'a', 'g', 'link')
                assert.ok(
                    fs.lstatSync(linkPath).isFile(),
                    'lstatSync should find file if link is in guard'
                )

                assert.ok(
                    (await util.promisify(fs.lstat)(linkPath)).isFile(),
                    'lstat should find file if link is in guard'
                )

                assert.ok(
                    (await fs.promises.lstat(linkPath)).isFile(),
                    'promises.lstat should find file if link is in guard'
                )

                revertPatches()
            }
        )
    })

    await it('lstat of symlink out of root is file.', async () => {
        await withFixtures(
            {
                a: {},
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                // create symlink from a/link to b/file
                fs.symlinkSync(
                    path.join(fixturesDir, 'b', 'file'),
                    path.join(fixturesDir, 'a', 'link')
                )

                const revertPatches = patcher([path.join(fixturesDir, 'a')])

                const linkPath = path.join(fixturesDir, 'a', 'link')

                assert.ok(
                    fs.lstatSync(linkPath).isFile(),
                    'lstatSync should find file it file link is out of root'
                )

                assert.ok(
                    (await util.promisify(fs.lstat)(linkPath)).isFile(),
                    'lstat should find file it file link is out of root'
                )

                assert.ok(
                    (await fs.promises.lstat(linkPath)).isFile(),
                    'promises.lstat should find file it file link is out of root'
                )

                let brokenLinkPath = path.join(fixturesDir, 'a', 'broken-link')
                fs.symlinkSync(
                    path.join(fixturesDir, 'doesnt-exist'),
                    brokenLinkPath
                )

                assert.ok(
                    fs.lstatSync(brokenLinkPath).isSymbolicLink(),
                    'if a symlink is broken but is escaping return it as a link.'
                )
                for (const bigint of [false, true]) {
                    const stats = fs.lstatSync(brokenLinkPath, {
                        bigint,
                        throwIfNoEntry: false,
                    })
                    assert.ok(stats.isSymbolicLink())
                    assert.equal(
                        typeof stats.size,
                        bigint ? 'bigint' : 'number'
                    )
                }
                assert.ok(
                    (
                        await util.promisify(fs.lstat)(brokenLinkPath)
                    ).isSymbolicLink(),
                    'if a symlink is broken but is escaping return it as a link.'
                )
                assert.ok(
                    (await fs.promises.lstat(brokenLinkPath)).isSymbolicLink(),
                    'if a symlink is broken but is escaping return it as a link.'
                )

                brokenLinkPath = path.join(fixturesDir, 'a', 'broken-link2')
                fs.symlinkSync(
                    path.join(fixturesDir, 'a', 'doesnt-exist'),
                    brokenLinkPath
                )

                const stat = await fs.promises.lstat(brokenLinkPath)
                assert.ok(
                    stat.isSymbolicLink(),
                    'if a symlink is broken but not escaping return it as a link.'
                )

                revertPatches()
            }
        )
    })

    await it('not in root, symlinks do what they would have before.', async () => {
        await withFixtures(
            {
                a: {},
                b: { file: 'contents' },
            },
            async (fixturesDir) => {
                fixturesDir = fs.realpathSync(fixturesDir)
                // create symlink from a/link to b/file
                fs.symlinkSync(
                    path.join(fixturesDir, 'b', 'file'),
                    path.join(fixturesDir, 'b', 'link')
                )

                const revertPatches = patcher([path.join(fixturesDir, 'a')])

                const linkPath = path.join(fixturesDir, 'b', 'link')

                assert.ok(
                    fs.lstatSync(linkPath).isSymbolicLink(),
                    'lstatSync should find symbolic link if link is out of the root'
                )

                assert.ok(
                    fs
                        .lstatSync(new URL(`file://${linkPath}`))
                        .isSymbolicLink(),
                    'lstatSync should find symbolic link if link is out of the root'
                )

                const stat = await util.promisify(fs.lstat)(linkPath)
                assert.ok(
                    stat.isSymbolicLink(),
                    'lstat should find symbolic link if link is outside'
                )

                assert.ok(
                    (await fs.promises.lstat(linkPath)).isSymbolicLink(),
                    'promises.lstat should find symbolic link if link is outside'
                )

                revertPatches()
            }
        )
    })

    await it('includes parent calls in stack traces', async function lstatStackTest1() {
        let err
        try {
            fs.lstatSync(null)
        } catch (e) {
            err = e
        } finally {
            if (!err) assert.fail('lstat should fail on invalid path')
            if (!err.stack.includes('lstatStackTest1'))
                assert.fail(
                    `lstat error stack should contain calling method: ${err.stack}`
                )
        }
    })
})
