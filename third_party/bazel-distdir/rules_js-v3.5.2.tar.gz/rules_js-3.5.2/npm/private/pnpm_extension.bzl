"""pnpm extension logic (the extension itself is in npm/extensions.bzl)."""

load(":pnpm_repository.bzl", "DEFAULT_PNPM_VERSION", "LATEST_PNPM_VERSION", "PNPM_EXE_PLATFORMS", "is_native_pnpm_version")
load(":utils.bzl", "utils")
load(":versions.bzl", "PNPM_EXE_VERSIONS", "PNPM_VERSIONS")

DEFAULT_PNPM_REPO_NAME = "pnpm"

# copied from https://github.com/bazelbuild/bazel-skylib/blob/b459822483e05da514b539578f81eeb8a705d600/lib/versions.bzl#L60
# to avoid taking a dependency on skylib here
def _parse_version(version):
    return tuple([int(n) for n in version.split(".")])

def resolve_pnpm_repositories(mctx):
    """Resolves pnpm tags in all `modules`

    Args:
      mctx: module context

    Returns:
      A struct with the following fields:
      - `repositories`: dict (name -> {version, include_npm, integrity}) to invoke `pnpm_repository` with.
      - `notes`: list of notes to print to the user.
      - `facts`: Bazel module Facts to persist for future use (may be None).
    """

    # Collect all the module tags and associated versions/integrities/options
    integrity = {}

    # Whether npm should be bundled with pnpm, OR'd across all tags for a repo
    # (name -> bool). Like patches, this is a per-repo setting, not per-version.
    include_npm_by_repo = {}

    # Patches and patch_args are per-repo-name (NOT per-version) and only
    # accepted from the root module. Multiple tags for the same repo name
    # concatenate their patches and the last patch_args wins.
    patches_by_repo = {}
    patch_args_by_repo = {}

    # Versions explicitly requested for each repo: name -> version -> is_root. Tags
    # that carry no version (the default, e.g. the always-present registration from
    # rules_js itself) are excluded, so they only matter as a fallback. A version
    # requested by the root module (is_root = True) takes priority over the rest.
    requested = {}
    for mod in mctx.modules:
        for attr in mod.tags.pnpm:
            if attr.name != DEFAULT_PNPM_REPO_NAME and not mod.is_root:
                fail("""\
                Only the root module may override the default name for the pnpm repository.
                This prevents conflicting registrations in the global namespace of external repos.
                """)
            if attr.name not in requested:
                requested[attr.name] = {}
                include_npm_by_repo[attr.name] = False
            include_npm_by_repo[attr.name] = include_npm_by_repo[attr.name] or attr.include_npm
            if mod.is_root and (getattr(attr, "patches", None) or getattr(attr, "patch_args", None)):
                patches_by_repo.setdefault(attr.name, [])
                patches_by_repo[attr.name].extend(getattr(attr, "patches", []) or [])
                patch_args_by_repo[attr.name] = list(attr.patch_args)

            if attr.pnpm_version_from and attr.pnpm_version:
                fail("Cannot specify both pnpm_version = {} and pnpm_version_from = {}".format(attr.pnpm_version, attr.pnpm_version_from))

            # A tag that specifies no version (neither pnpm_version nor pnpm_version_from)
            # carries the default version, e.g. the registration from rules_js itself.
            # Such registrations must not influence version selection when any module
            # explicitly requests a version.
            is_default_registration = attr.pnpm_version == "" and attr.pnpm_version_from == None

            # Handle pnpm_version_from by reading package.json
            if attr.pnpm_version_from != None:
                # Read package.json and extract packageManager field
                package_json_content = mctx.read(attr.pnpm_version_from)
                package_json = json.decode(package_json_content)

                if "packageManager" not in package_json:
                    fail("packageManager field not found in package.json file: " + str(attr.pnpm_version_from))

                package_manager = package_json["packageManager"]
                if not package_manager.startswith("pnpm@"):
                    fail("packageManager field must specify pnpm, got: " + package_manager)

                # Extract version and optional integrity from "pnpm@8.15.9+sha512.<hash>" format
                v = package_manager[5:]  # Remove "pnpm@" prefix
                if "+sha512." in v:
                    parts = v.rsplit("+sha512.", 1)
                    v = parts[0]

                    # Store the integrity hash. We need to convert the hex representation of the
                    # hash used by corepack, to the one Bazel understands: base64 encoded with a
                    # "sha512-" prefix.
                    integrity[v] = "sha512-" + utils.hex_to_base64(parts[1])

            elif attr.pnpm_version == "latest":
                v = LATEST_PNPM_VERSION
            elif attr.pnpm_version == "":
                v = DEFAULT_PNPM_VERSION
            else:
                v = attr.pnpm_version

            if not is_default_registration:
                requested[attr.name][v] = requested[attr.name].get(v, False) or mod.is_root
            if attr.pnpm_version_integrity:
                integrity[v] = attr.pnpm_version_integrity

            # If no integrity was provided or found via package.json load from known versions
            if not integrity.get(v, False) and PNPM_VERSIONS.get(v, False):
                integrity[v] = PNPM_VERSIONS[v]

    # From the collected registrations, resolve to a single version per repository name
    notes = []
    repositories = {}
    for name, version_requests in requested.items():
        # Versions requested by the root module take priority, then versions requested
        # by any other module, falling back to the default version when no module
        # requested a specific version.
        root_versions = [v for v in version_requests if version_requests[v]]
        versions = root_versions or version_requests.keys() or [DEFAULT_PNPM_VERSION]

        # Within the selected tier, pick the highest version like bzlmod does. This
        # runs after the tiering above, so a root request wins even if it is lower.
        # Note, the 'sorted(list)' function in starlark doesn't allow us to provide a custom comparator
        if len(versions) > 1:
            selected = versions[0]
            selected_tuple = _parse_version(selected)
            for idx in range(1, len(versions)):
                if _parse_version(versions[idx]) > selected_tuple:
                    selected = versions[idx]
                    selected_tuple = _parse_version(selected)

            notes.append("NOTE: repo '{}' has multiple versions {}; selected {}".format(name, versions, selected))
        else:
            selected = versions[0]

        selected = {
            "version": selected,
            "include_npm": include_npm_by_repo[name],
            "integrity": integrity.get(selected, None),
            "patches": patches_by_repo.get(name, []),
            "patch_args": patch_args_by_repo.get(name, ["-p1"]),
        }

        # pnpm 12+ also needs the integrity of the platform binary packages.
        if is_native_pnpm_version(selected["version"]):
            selected["exe_integrity"] = PNPM_EXE_VERSIONS.get(selected["version"], None)

        repositories[name] = selected

    # If any repositories have no known integrity, try to fetch them from the npm registry and persist
    # them as Facts for future use.
    fetched_facts = None
    used_facts = None
    missing_integrity = len([v for v in repositories.values() if not v["integrity"] or v.get("exe_integrity", True) == None]) > 0
    if hasattr(mctx, "facts") and missing_integrity:
        used_facts = {}
        for pnpm in repositories.values():
            if not pnpm["integrity"]:
                # Try fetching from any pre-existing facts first
                integrity = mctx.facts.get(pnpm["version"], None)
                if not integrity:
                    # Only fetch the list of pnpm versions once, and only if the version is not found in existing facts
                    if not fetched_facts:
                        fetched_facts = _fetch_pnpm_versions(mctx)
                    integrity = fetched_facts.get(pnpm["version"], None)

                if integrity:
                    pnpm["integrity"] = integrity
                    used_facts[pnpm["version"]] = integrity

            if pnpm.get("exe_integrity", True) == None:
                # pnpm 12+ platform binaries of a version not mirrored in versions.bzl.
                exe_fact_key = "exe:" + pnpm["version"]
                exe_integrity = mctx.facts.get(exe_fact_key, None)
                if exe_integrity:
                    exe_integrity = json.decode(exe_integrity)
                else:
                    exe_integrity = _fetch_pnpm_exe_integrity(mctx, pnpm["version"])

                if exe_integrity:
                    pnpm["exe_integrity"] = exe_integrity
                    used_facts[exe_fact_key] = json.encode(exe_integrity)

    return struct(
        repositories = repositories,
        notes = notes,
        facts = used_facts,
    )

def _fetch_pnpm_exe_integrity(module_ctx, version):
    """Fetches the integrity of each @pnpm/exe.* platform binary of a pnpm version.

    Returns:
        A dict mapping platform (e.g. "darwin-arm64") to integrity, or None on failure.
    """
    exe_integrity = {}
    for platform in PNPM_EXE_PLATFORMS:
        out = "pnpm_exe_{}.json".format(platform)
        result = module_ctx.download(
            url = ["https://registry.npmjs.org/@pnpm/exe.{}/{}".format(platform, version)],
            output = out,
        )
        if not result.success:
            # buildifier: disable=print
            print("ERROR: failed to fetch @pnpm/exe.{}@{} metadata from npm registry: {}".format(platform, version, result))
            return None

        data = module_ctx.read(out)
        if not data or data[0] != "{":
            # buildifier: disable=print
            print("ERROR: failed to read @pnpm/exe.{}@{} metadata fetched from npm registry: {}".format(platform, version, data))
            return None

        integrity = json.decode(data).get("dist", {}).get("integrity", None)
        if not integrity:
            return None
        exe_integrity[platform] = integrity
    return exe_integrity

def _fetch_pnpm_versions(module_ctx):
    """Fetches pnpm versions and their integrity hashes from the npm registry.

    Returns:
        A dict mapping version strings to dicts with 'integrity' keys.
    """
    result = module_ctx.download(url = ["https://registry.npmjs.org/pnpm"], output = "pnpm_versions.json")
    if not result.success:
        # buildifier: disable=print
        print("ERROR: failed to fetch pnpm versions from npm registry: {}".format(result))
        return None

    data = module_ctx.read("pnpm_versions.json")

    # If the download failed such as being redirected to a custom registry page, the data may not be valid JSON
    # and can just be ignored with warning.
    if not data or data[0] != "{":
        # buildifier: disable=print
        print("ERROR: failed to read pnpm versions fetched from npm registry: {}".format(data))
        return None

    data = json.decode(data)
    versions = {}
    for version, info in data.get("versions", {}).items():
        if int(version.split(".")[0]) < 9:
            # Skip pnpm versions below 9
            continue

        dist = info.get("dist", {})
        integrity = dist.get("integrity", None)
        if integrity:
            versions[version] = integrity
    return versions
