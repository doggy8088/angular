"""Starlark helpers for npm_translate_lock."""

load("@bazel_lib//lib:base64.bzl", "base64")
load("@bazel_skylib//lib:new_sets.bzl", "sets")
load("@bazel_skylib//lib:paths.bzl", "paths")
load(":utils.bzl", "utils")

################################################################################
def _check_for_conflicting_public_links(npm_imports, public_hoist_packages):
    if not public_hoist_packages:
        return
    all_public_links = {}
    for _import in npm_imports:
        for link_package, link_names in _import.link_packages.items():
            if link_package not in all_public_links:
                all_public_links[link_package] = {}
            for link_name in link_names:
                if link_name not in all_public_links[link_package]:
                    all_public_links[link_package][link_name] = []
                all_public_links[link_package][link_name].append("{}@{}".format(_import.package, _import.version))
    for link_package, link_names in all_public_links.items():
        for link_name, link_packages in link_names.items():
            if len(link_packages) > 1:
                if link_name in public_hoist_packages:
                    msg = """\n\nInvalid public hoist configuration with multiple packages to hoist to '{link_package}/node_modules/{link_name}': {link_packages}

Trying selecting a specific version of '{link_name}' to hoist in public_hoist_packages. For example '{link_packages_first}':

    public_hoist_packages = {{
        "{link_packages_first}": ["{link_package}"]
    }}
""".format(
                        link_package = link_package,
                        link_name = link_name,
                        link_packages = link_packages,
                        link_packages_first = link_packages[0],
                    )
                else:
                    msg = """\n\nInvalid public hoist configuration with multiple packages to hoist to '{link_package}/node_modules/{link_name}': {link_packages}

Check the public_hoist_packages attribute for duplicates.
""".format(
                        link_package = link_package,
                        link_name = link_name,
                        link_packages = link_packages,
                    )
                fail(msg)

################################################################################
def _gather_package_content_excludes(config, *names):
    """Gather exclude patterns and presets for a package.

    More specific package matches override less specific ones (first match wins).
    The wildcard "*" config is only used if no specific package match is found.

    Args:
        config: Dict mapping package names to struct(patterns, presets)
        *names: Package names to look up in order of precedence (e.g., name, friendly_name, unfriendly_name)

    Returns:
        A struct with patterns (list or None) and presets (list)
    """

    # Find the first matching config (most specific match wins, does not extend)
    for name in names:
        if name in config:
            value = config[name]
            return struct(
                patterns = value.patterns,
                presets = value.presets,
            )

    # Fall back to wildcard if no specific match
    if "*" in config:
        wildcard = config["*"]
        return struct(patterns = wildcard.patterns, presets = wildcard.presets)

    # Must repeat the default here since it is passed through to `npm_import()`
    # and overrides the default exclude patterns defined by the rule.
    return struct(patterns = None, presets = ["basic"])

################################################################################
def _gather_values_from_matching_names(additive, keyed_lists, *names):
    keys = []
    result = []
    for name in names:
        if name and name in keyed_lists:
            keys.append(name)
            v = keyed_lists[name]
            if additive:
                if type(v) == "list":
                    result.extend(v)
                elif type(v) == "string":
                    result.append(v)
                else:
                    fail("expected value to be list or string")
            elif type(v) == "list":
                result = v
            elif type(v) == "string":
                result = [v]
            else:
                fail("expected value to be list or string")
    return (result, keys)

def _is_absolute_path(path):
    if path.startswith("/") or path.startswith("\\"):
        return True

    # Windows drive path, e.g. C:\ or C:/
    return len(path) >= 3 and path[1] == ":" and (path[2] == "/" or path[2] == "\\")

def _run_token_helper(helper, npmrc_path, rctx):
    # tokenHelper values may reference env vars, same as any other credential value
    helper = utils.replace_npmrc_token_envvar(helper, npmrc_path, rctx)

    # An empty value would otherwise resolve to the `.npmrc`'s own directory and be executed
    if not helper:
        fail("tokenHelper in \"{npmrc}\" is empty; it must name an executable".format(npmrc = npmrc_path))

    # A relative helper is resolved against the directory of the `.npmrc` that declared it,
    # so a checked-in file can point at a script next to it.
    if not _is_absolute_path(helper):
        helper = str(rctx.path(str(npmrc_path)).dirname) + "/" + helper

    result = rctx.execute([helper])
    if result.return_code != 0:
        # Deliberately omit stdout: a helper writes its token there, so echoing it on
        # failure would leak the credential into the terminal and CI logs.
        fail("tokenHelper \"{helper}\" in \"{npmrc}\" exited with {code}:\nSTDERR:\n{stderr}".format(
            helper = helper,
            npmrc = npmrc_path,
            code = result.return_code,
            stderr = result.stderr,
        ))

    token = result.stdout.strip()
    if not token:
        fail("tokenHelper \"{helper}\" in \"{npmrc}\" produced no output".format(
            helper = helper,
            npmrc = npmrc_path,
        ))

    return token

################################################################################
def _pnpm_workspace_registries(registries):
    """Normalizes the `registries` setting of `pnpm-workspace.yaml` into a scope to URL map.

    Both shapes pnpm accepts are handled: `{"@scope": url, "default": url}` and, since pnpm 11.23,
    `{url: {"scopes": ["@scope", "@"], ...}}` where the bare `@` scope names the default registry.

    Args:
        registries: The parsed `registries` setting.

    Returns:
        A dict of scope (or `"default"`) to registry URL.
    """
    by_scope = {}
    for key, value in registries.items():
        if type(value) == "string":
            by_scope[key] = utils.to_registry_url(value)
        else:
            for scope in value.get("scopes", []):
                by_scope["default" if scope == "@" else scope] = utils.to_registry_url(key)
    return by_scope

def _pnpm_workspace_registry_urls(registries):
    """Lists every registry URL the `registries` setting of `pnpm-workspace.yaml` declares.

    Unlike `_pnpm_workspace_registries` this includes registries reached only through a
    `prefix`, which have no scope to route by but still need credentials.

    Args:
        registries: The parsed `registries` setting.

    Returns:
        A list of registry URLs.
    """
    return [utils.to_registry_url(value if type(value) == "string" else key) for key, value in registries.items()]

################################################################################
def _credential_helper_for(url, helpers_by_scope):
    """Picks the credential helper for a registry the way Bazel's `--credential_helper` scopes do.

    Args:
        url: The registry URL.
        helpers_by_scope: A dict of scope to helper. A scope is a host, a `*.domain` wildcard that
            also matches the domain itself, or `""` for every host.

    Returns:
        The helper of the exact host, else of the most specific wildcard, else the unscoped one,
        else None.
    """
    host = url.split("//", 1)[-1].split("/", 1)[0].split(":", 1)[0]
    if host in helpers_by_scope:
        return helpers_by_scope[host]

    labels = host.split(".")
    for i in range(len(labels)):
        wildcard = "*." + ".".join(labels[i:])
        if wildcard in helpers_by_scope:
            return helpers_by_scope[wildcard]

    return helpers_by_scope.get("")

################################################################################
def _pnpm_auth_env(authorization):
    """Converts Authorization headers into the environment variables pnpm reads registry auth from.

    Args:
        authorization: A dict of registry URL to Authorization header value, e.g.
            `{"https://registry.corp.com/": "Bearer TOKEN"}`.

    Returns:
        A dict of URL-scoped `pnpm_config_` environment variables, e.g.
        `{"pnpm_config_//registry.corp.com/:_authToken": "TOKEN"}`. pnpm 11.6 and newer read the
        `pnpm_config_` prefix and prefer it over `npm_config_`.
    """
    env = {}
    for url, header in authorization.items():
        scheme, _, credential = header.partition(" ")
        key = "pnpm_config_//" + url.split("//", 1)[-1].removesuffix("/") + "/:"
        if scheme.lower() == "bearer":
            env[key + "_authToken"] = credential
        elif scheme.lower() == "basic":
            env[key + "_auth"] = credential
        else:
            fail("unsupported Authorization scheme `{}` for registry {}".format(scheme, url))
    return env

################################################################################
def _get_npm_auth(npmrc, npmrc_path, rctx):
    """Parses npm tokens, registries and scopes from `.npmrc`.

    - creates a token by registry dict: {registry: token}
    - creates a registry by scope dict: {scope: registry}

    For example:
        Given the following `.npmrc`:

        ```
        @myorg:registry=https://somewhere-else.com/myorg
        @another:registry=https://somewhere-else.com/another
        @basic:registry=https://somewhere-else.com/basic
        ; would apply only to @myorg
        //somewhere-else.com/myorg/:_authToken=MYTOKEN1
        ; would apply only to @another
        //somewhere-else.com/another/:_auth=dXNlcm5hbWU6cGFzc3dvcmQ===
        ; would apply only to @basic
        //somewhere-else.com/basic/:username=someone
        //somewhere-else.com/basic/:_password=aHVudGVyMg==
        ```

        `get_npm_auth(npmrc, npmrc_path, environ)` creates the following dict:

        ```starlark
        registries = {
                "@myorg": "somewhere-else.com/myorg",
                "@another": "somewhere-else.com/another",
                "@basic": "somewhere-else.com/basic",
        }
        auth = {
            "somewhere-else.com/myorg": {
                "bearer": MYTOKEN1",
            },
            "somewhere-else.com/another": {
                "basic": dXNlcm5hbWU6cGFzc3dvcmQ===",
            },
            "somewhere-else.com/basic": {
                "username": "someone",
                "password": "hunter2",
            },
        }
        ```

        A `tokenHelper` yields a `"token_helper"` entry instead of a `"bearer"` one; it is not run
        here, but by `_select_npm_auth` the first time it picks auth for that registry.

    Args:
        npmrc: The `.npmrc` file.
        npmrc_path: The file path to `.npmrc`.
        rctx: the repository_ctx or module_ctx to fetch environment vars from

    Returns:
        A tuple (registries, auth).
    """

    # _NPM_AUTH_TOKEN is case-sensitive. Should be the same as pnpm's
    # https://github.com/pnpm/pnpm/blob/4097af6b5c09d9de1a3570d531bb4bb89c093a04/network/auth-header/src/getAuthHeadersFromConfig.ts#L17
    _NPM_AUTH_TOKEN = "_authToken"
    _NPM_AUTH = "_auth"
    _NPM_USERNAME = "username"
    _NPM_PASSWORD = "_password"
    _NPM_TOKEN_HELPER = "tokenHelper"
    _NPM_PKG_SCOPE_KEY = ":registry"
    registries = {}
    auth = {}
    token_helpers = {}

    for (k, v) in npmrc.items():
        if k == _NPM_AUTH_TOKEN or k.endswith(":" + _NPM_AUTH_TOKEN):
            # //somewhere-else.com/myorg/:_authToken=MYTOKEN1
            # registry: somewhere-else.com/myorg
            # token: MYTOKEN1
            registry = k.removeprefix("//").removesuffix(_NPM_AUTH_TOKEN).removesuffix(":").removesuffix("/")

            # envvar replacement is supported for `_authToken`
            # https://pnpm.io/npmrc#url_authtoken
            token = utils.replace_npmrc_token_envvar(v, npmrc_path, rctx)

            if registry not in auth:
                auth[registry] = {}

            auth[registry]["bearer"] = token

        # global "registry" key is special cased elsewhere
        if k.endswith(_NPM_PKG_SCOPE_KEY):
            # @myorg:registry=https://somewhere-else.com/myorg
            # scope: @myorg
            # registry: somewhere-else.com/myorg
            scope = k.removesuffix(_NPM_PKG_SCOPE_KEY)
            registry = utils.to_registry_url(v)
            registries[scope] = registry

        if k == _NPM_AUTH or k.endswith(":" + _NPM_AUTH):
            # //somewhere-else.com/myorg/:username=someone
            # registry: somewhere-else.com/myorg
            # username: someone
            registry = k.removeprefix("//").removesuffix(_NPM_AUTH).removesuffix(":").removesuffix("/")

            # envvar replacement is supported for `_auth` as well
            token = utils.replace_npmrc_token_envvar(v, npmrc_path, rctx)

            if registry not in auth:
                auth[registry] = {}

            auth[registry]["basic"] = token

        if k == _NPM_USERNAME or k.endswith(":" + _NPM_USERNAME):
            # //somewhere-else.com/myorg/:username=someone
            # registry: somewhere-else.com/myorg
            # username: someone
            registry = k.removeprefix("//").removesuffix(_NPM_USERNAME).removesuffix(":").removesuffix("/")

            if registry not in auth:
                auth[registry] = {}

            auth[registry]["username"] = v

        if k == _NPM_PASSWORD or k.endswith(":" + _NPM_PASSWORD):
            # //somewhere-else.com/myorg/:_password=aHVudGVyMg==
            # registry: somewhere-else.com/myorg
            # _password: aHVudGVyMg==
            registry = k.removeprefix("//").removesuffix(_NPM_PASSWORD).removesuffix(":").removesuffix("/")

            if registry not in auth:
                auth[registry] = {}

            auth[registry]["password"] = base64.decode(v)

        if k == _NPM_TOKEN_HELPER or k.endswith(":" + _NPM_TOKEN_HELPER):
            # //registry.corp.com/:tokenHelper=/abs/path
            # registry: registry.corp.com
            registry = k.removeprefix("//").removesuffix(_NPM_TOKEN_HELPER).removesuffix(":").removesuffix("/")
            token_helpers[registry] = v

    # Record helpers rather than running them. _select_npm_auth runs one when it picks auth for a
    # package URL, so a helper for a registry nothing in the lockfile resolves to never runs.
    for (registry, helper) in token_helpers.items():
        if registry not in auth:
            auth[registry] = {}

        # A helper wins over a static token, and must not shadow its own memoized result
        auth[registry].pop("bearer", None)
        auth[registry]["token_helper"] = struct(command = helper, npmrc_path = npmrc_path)

    return (registries, auth)

def _registry_matches(registry, auth_registry):
    # A plain prefix test would send credentials to a lookalike host, since
    # "registry.corp.company.com" starts with "registry.corp.com". Require a path boundary.
    return registry == auth_registry or registry.startswith(auth_registry + "/")

################################################################################
def _select_npm_auth(url, npm_auth, rctx = None):
    registry = url.split("//", 1)[-1]

    # Get rid of the port number
    registry_no_port = registry
    if ":" in registry:
        components = registry.split(":", 1)
        base = components[0]

        path = components[1].split("/", 1)
        if len(path) == 2:
            registry_no_port = base + "/" + path[1]
        else:
            registry_no_port = base

    matched = None
    match_len = 0
    for auth_registry, auth_info in npm_auth.items():
        if auth_registry == "":
            # global auth applied to all registries; will be overridden by a registry scoped auth
            if matched == None:
                matched = auth_info
        elif len(auth_registry) > match_len and (_registry_matches(registry, auth_registry) or _registry_matches(registry_no_port, auth_registry)):
            # keep the longest match, not the first one the dict happens to yield
            matched = auth_info
            match_len = len(auth_registry)

    if matched == None:
        return None, None, None, None

    # Memoized into the auth entry so a helper runs once per registry, not once per package
    helper = matched.get("token_helper")
    if helper and "bearer" not in matched:
        matched["bearer"] = _run_token_helper(helper.command, helper.npmrc_path, rctx)

    return (
        matched.get("bearer"),
        matched.get("basic"),
        matched.get("username"),
        matched.get("password"),
    )

################################################################################
def _lifecycle_attrs(attr):
    """Convert lifecycle-related extension tag attrs into values to pass to npm_import"""
    if not attr.run_lifecycle_hooks:
        return False, {}, {}

    # lifecycle_hooks_exclude is a convenience attribute to set `<value>: []` in `lifecycle_hooks`
    all_lifecycle_hooks = dict(attr.lifecycle_hooks)
    for p in attr.lifecycle_hooks_exclude:
        if p in all_lifecycle_hooks:
            fail("expected '{}' to be in only one of lifecycle_hooks or lifecycle_hooks_exclude".format(p))
        all_lifecycle_hooks[p] = []
    if "*" not in all_lifecycle_hooks:
        all_lifecycle_hooks["*"] = ["preinstall", "install", "postinstall"]

    # lifecycle_hooks_no_sandbox is a convenience attribute to set `"*": ["no-sandbox"]` in `lifecycle_hooks_execution_requirements`
    all_lifecycle_hooks_execution_requirements = attr.lifecycle_hooks_execution_requirements
    if attr.lifecycle_hooks_no_sandbox:
        all_lifecycle_hooks_execution_requirements = dict(all_lifecycle_hooks_execution_requirements)
        execution_requirements = all_lifecycle_hooks_execution_requirements.get("*")
        if not execution_requirements:
            execution_requirements = []
            all_lifecycle_hooks_execution_requirements["*"] = execution_requirements
        if "no-sandbox" not in execution_requirements:
            execution_requirements.append("no-sandbox")

    # Convert {"pkg": True|False} to {"pkg": "true"|"false"} and set a default value for "*"
    all_lifecycle_hooks_use_default_shell_env = {}
    for p in attr.lifecycle_hooks_use_default_shell_env:
        all_lifecycle_hooks_use_default_shell_env[p] = "true" if attr.lifecycle_hooks_use_default_shell_env[p] else "false"
    if "*" not in all_lifecycle_hooks_use_default_shell_env:
        all_lifecycle_hooks_use_default_shell_env["*"] = "false"

    return all_lifecycle_hooks, all_lifecycle_hooks_execution_requirements, all_lifecycle_hooks_use_default_shell_env

################################################################################
def _get_npm_imports(state, replace_packages, attr, registries, npm_auth, exclude_package_contents_config, rctx = None):
    "Converts packages from the lockfile to a struct of attributes for npm_import"

    importers = state.importers()
    packages = state.packages()
    only_built_dependencies = state.only_built_dependencies()
    root_package = state.root_package()
    default_registry = state.default_registry()

    all_lifecycle_hooks, all_lifecycle_hooks_execution_requirements, all_lifecycle_hooks_use_default_shell_env = _lifecycle_attrs(attr)

    # Direct dependencies of 'importers' which will have public targets
    direct_deps = {}

    # A map of which importers depend on which packages (and by which name) to
    # quickly map package => dependents.
    package_importers = {}
    for importer_path, importer in importers.items():
        dependencies = importer["dependencies"] | importer["optional_dependencies"] | importer["dev_dependencies"]

        link_package = _link_package(root_package, importer_path)

        for dep_package, dep_package_key in dependencies.items():
            direct_deps[dep_package_key] = True

            if dep_package_key.startswith("link:"):
                continue

            if dep_package_key not in package_importers:
                package_importers[dep_package_key] = {link_package: [dep_package]}
            elif link_package not in package_importers[dep_package_key]:
                package_importers[dep_package_key][link_package] = [dep_package]
            elif dep_package not in package_importers[dep_package_key][link_package]:
                package_importers[dep_package_key][link_package].append(dep_package)

    patches_used = []
    result = []
    for package_key, package_info in packages.items():
        name = package_info["name"]
        version = package_info["version"]
        friendly_version = package_info["friendly_version"]
        transitive_closure = package_info.get("transitive_closure", {}) | package_info.get("transitive_optional_closure", {})
        resolution = package_info["resolution"]

        resolution_type = resolution.get("type", None)
        if resolution_type == "directory":
            # this package is treated as a first-party dep
            continue

        integrity = resolution.get("integrity", None)
        tarball = resolution.get("tarball", None)
        registry = resolution.get("registry", None)
        repo = resolution.get("repo", None)
        commit = resolution.get("commit", None)

        if resolution_type == "git":
            if not repo or not commit:
                msg = "expected package {} resolution to have repo and commit fields when resolution type is git".format(package_key)
                fail(msg)
        elif not integrity and not tarball:
            msg = "expected package {} resolution to have an integrity or tarball field but found none".format(package_key)
            fail(msg)

        friendly_name = utils.friendly_name(name, friendly_version)
        unfriendly_name = utils.friendly_name(name, version)
        if unfriendly_name == friendly_name:
            # there is no unfriendly name for this package
            unfriendly_name = None

        # gather patches & patch args
        patches = []
        patch_args = []

        translate_patches, patches_keys = _gather_values_from_matching_names(True, attr.patches, name, friendly_name, unfriendly_name)

        pnpm_patch = state.pnpm_patch_for(friendly_name) or state.pnpm_patch_for(name)
        pnpm_patched = pnpm_patch != None

        if len(translate_patches) > 0 and pnpm_patched:
            msg = """\
ERROR: can not apply both `pnpm.patchedDependencies` and `npm_translate_lock(patches)` to the same package {pkg}.
""".format(
                pkg = name,
            )
            fail(msg)

        # Apply patch from `pnpm.patchedDependencies` first
        if pnpm_patched:
            patch_path = "//%s:%s" % (attr.pnpm_lock.package, pnpm_patch)
            patches.append(patch_path)

            # pnpm patches are always applied with -p1
            patch_args = ["-p1"]
        elif len(translate_patches) > 0:
            patches = translate_patches
            patch_args, _ = _gather_values_from_matching_names(False, attr.patch_args, "*", name, friendly_name, unfriendly_name)
            patches_used.extend(patches_keys)

        # Resolve string patch labels relative to the root respository rather than relative to rules_js.
        # https://docs.google.com/document/d/1N81qfCa8oskCk5LqTW-LNthy6EBrDot7bdUsjz6JFC4/
        patches = [attr.pnpm_lock.relative(patch) for patch in patches]

        exclude_package_contents_result = _gather_package_content_excludes(exclude_package_contents_config, name, friendly_name, unfriendly_name)

        # gather replace packages
        replace_package, _ = _gather_values_from_matching_names(True, replace_packages, name, friendly_name, unfriendly_name)
        if len(replace_package) > 1:
            msg = "Multiple package replacements found for package {}".format(name)
            fail(msg)
        replace_package = replace_package[0] if replace_package else None

        # gather custom postinstalls
        custom_postinstalls, _ = _gather_values_from_matching_names(True, attr.custom_postinstalls, name, friendly_name, unfriendly_name)
        custom_postinstall = " && ".join([c for c in custom_postinstalls if c])

        repo_name = utils.package_repo_name(attr.name, package_key)

        # gather package visibility
        package_visibility, _ = _gather_values_from_matching_names(True, attr.package_visibility, "*", name, friendly_name, unfriendly_name)
        if len(package_visibility) == 0:
            package_visibility = ["//visibility:public"]

        # Bazel package which this pnpm package should be linked at which names
        link_packages = package_importers.get(package_key, {})

        # check if this package should be hoisted via public_hoist_packages
        public_hoist_packages, _ = _gather_values_from_matching_names(True, attr.public_hoist_packages, name, friendly_name, unfriendly_name)
        for public_hoist_package in public_hoist_packages:
            if public_hoist_package not in link_packages:
                link_packages[public_hoist_package] = [name]
            elif name not in link_packages[public_hoist_package]:
                link_packages[public_hoist_package].append(name)

        run_lifecycle_hooks = all_lifecycle_hooks and only_built_dependencies != None and name in only_built_dependencies
        if run_lifecycle_hooks:
            lifecycle_hooks, _ = _gather_values_from_matching_names(False, all_lifecycle_hooks, "*", name, friendly_name, unfriendly_name)
            lifecycle_hooks_env, _ = _gather_values_from_matching_names(True, attr.lifecycle_hooks_envs, "*", name, friendly_name, unfriendly_name)
            lifecycle_hooks_execution_requirements, _ = _gather_values_from_matching_names(False, all_lifecycle_hooks_execution_requirements, "*", name, friendly_name, unfriendly_name)
            lifecycle_hooks_use_default_shell_env, _ = _gather_values_from_matching_names(False, all_lifecycle_hooks_use_default_shell_env, "*", name, friendly_name, unfriendly_name)
        else:
            lifecycle_hooks = False
            lifecycle_hooks_env = []
            lifecycle_hooks_execution_requirements = []
            lifecycle_hooks_use_default_shell_env = False

        bins = {}
        matching_bins, _ = _gather_values_from_matching_names(False, attr.bins, "*", name, friendly_name, unfriendly_name)
        for bin in matching_bins:
            key_value = bin.split("=", 1)
            if len(key_value) == 2:
                bins[key_value[0]] = key_value[1]
            else:
                msg = "bins contains invalid key value pair '{}', required '=' separator not found".format(bin)
                fail(msg)

        if resolution_type == "git":
            url = repo
        elif tarball:
            if _is_url(tarball):
                # pnpm sometimes prefixes the `tarball` url with the default npm registry `https://registry.npmjs.org/`
                # in pnpm-lock.yaml which we must replace with the desired registry in the `registry` field:
                #   tarball: https://registry.npmjs.org/@types/cacheable-request/-/cacheable-request-6.0.2.tgz
                #   registry: https://registry.yarnpkg.com/
                if registry and tarball.startswith(utils.default_registry()):
                    url = registry + tarball[len(utils.default_registry()):]
                else:
                    url = tarball
            elif tarball.startswith("file:"):
                file_path = tarball[5:]
                file_path = paths.normalize(paths.join(root_package, file_path))
                url = "file:{}".format(file_path)
            else:
                if not registry:
                    registry = utils.npm_registry_url(name, registries, default_registry)
                url = "{}/{}".format(registry.removesuffix("/"), tarball)
        else:
            url = utils.npm_registry_download_url(name, friendly_version, registries, default_registry)

        npm_auth_bearer, npm_auth_basic, npm_auth_username, npm_auth_password = _select_npm_auth(url, npm_auth, rctx)

        deps_oss, deps_cpus = _collect_dep_constraints(packages, package_info)

        result_pkg = struct(
            custom_postinstall = custom_postinstall,
            deps = package_info["dependencies"] | package_info["optional_dependencies"],
            deps_oss = deps_oss,
            deps_cpus = deps_cpus,
            integrity = integrity,
            link_packages = link_packages,
            repo_name = repo_name,
            is_direct_dep = package_key in direct_deps,
            package_key = package_key,
            package = name,
            package_visibility = package_visibility,
            patch_tool = attr.patch_tool,
            patch_args = patch_args,
            patches = patches,
            exclude_package_contents = exclude_package_contents_result.patterns,
            exclude_package_contents_presets = exclude_package_contents_result.presets,
            lifecycle_hooks = lifecycle_hooks,
            lifecycle_hooks_env = lifecycle_hooks_env,
            lifecycle_hooks_execution_requirements = lifecycle_hooks_execution_requirements,
            lifecycle_hooks_use_default_shell_env = lifecycle_hooks_use_default_shell_env and lifecycle_hooks_use_default_shell_env[0] == "true",
            npm_auth = npm_auth_bearer,
            npm_auth_basic = npm_auth_basic,
            npm_auth_username = npm_auth_username,
            npm_auth_password = npm_auth_password,
            transitive_closure = transitive_closure if len(transitive_closure) else None,
            url = url,
            commit = commit,
            version = version,
            bins = bins,
            package_info = package_info,
            replace_package = replace_package,
        )

        result.append(result_pkg)

    # Check that all patches files specified were used; this is a defense-in-depth since it is too
    # easy to make a typo in the patches keys or for a dep to change both of which could result
    # in a patch file being silently ignored.
    for key in attr.patches.keys():
        if key not in patches_used:
            msg = """

ERROR: Patch file key `{key}` does not match any npm packages in `npm_translate_lock(name = "{repo}").

Either remove this patch file if it is no longer needed or change its key to match an existing npm package.

""".format(
                key = key,
                repo = attr.name,
            )
            fail(msg)

    # check all links and fail if there are duplicates which can happen with public hoisting
    _check_for_conflicting_public_links(result, attr.public_hoist_packages)

    return result

################################################################################
def _collect_dep_constraints(packages, package_info):
    # Quick-exit for packages with no optional dependencies
    if not package_info["optional_dependencies"] and not package_info.get("transitive_optional_closure", None):
        return None, None

    constraints_os = {}
    constraints_cpu = {}

    optional_keys = package_info["optional_dependencies"].values() + package_info.get("transitive_optional_closure", {}).keys()
    for dep_key in optional_keys:
        if dep_key.startswith("link:"):
            continue

        dep = packages[dep_key]
        if dep["os"]:
            constraints_os[dep_key] = dep["os"]
        if dep["cpu"]:
            constraints_cpu[dep_key] = dep["cpu"]

    return constraints_os, constraints_cpu

################################################################################
def _link_package(root_package, import_path, rel_path = "."):
    link_package = paths.normalize(paths.join(root_package, import_path, rel_path))
    if link_package.startswith("../"):
        msg = "Invalid link_package outside of the repository: {}".format(link_package)
        fail(msg)
    if link_package == ".":
        link_package = ""
    return link_package

################################################################################
def _is_url(url):
    return url.find("://") != -1

################################################################################
def _to_apparent_repo_name(canonical_name):
    # Bazel 7 uses `~` as the canonical name separator by default, Bazel 8 always uses `+`.
    return canonical_name[max(canonical_name.rfind("~"), canonical_name.rfind("+")) + 1:]

################################################################################
def _verify_node_modules_ignored(rctx, attr, state):
    if attr.verify_node_modules_ignored != None:
        missing_ignores = _find_missing_bazel_ignores(state.root_package(), state.importers().keys(), rctx.read(rctx.path(attr.verify_node_modules_ignored)))
        if missing_ignores:
            msg = """

ERROR: in verify_node_modules_ignored:
pnpm install will create nested node_modules, but not all of them are ignored by Bazel.
We recommend that all node_modules folders in the source tree be ignored,
to avoid Bazel printing confusing error messages.

Possible fixes:
  - Upgrade to Bazel 8.0 and use ignore_directories(["**/node_modules"]) in REPO.bazel
  - Disable this check by removing `verify_node_modules_ignored` in `npm_translate_lock(name = "{repo}")`
  - Add line(s) to {bazelignore}:

{fixes}
                """.format(
                fixes = "\n".join(missing_ignores),
                bazelignore = attr.verify_node_modules_ignored,
                repo = attr.name,
            )
            fail(msg)

def _find_missing_bazel_ignores(root_package, importer_paths, bazelignore):
    bazelignore = _normalize_bazelignore(bazelignore.split("\n"))
    missing_ignores = []

    # The pnpm-lock.yaml file package needs to be prefixed on paths
    for i in importer_paths:
        expected = paths.normalize(paths.join(root_package, i, "node_modules"))
        if expected not in bazelignore:
            missing_ignores.append(expected)
    return missing_ignores

def _normalize_bazelignore(lines):
    """Make bazelignore lines predictable

    - strip trailing slash so that users can have either of equivalent
        foo/node_modules or foo/node_modules/
    - strip trailing carriage return on Windows
    - strip leading ./ so users can have node_modules or ./node_modules
    """
    result = []

    # N.B. from https://bazel.build/rules/lib/string#rstrip:
    # Note that chars is not a suffix: all combinations of its value are removed
    strip_trailing_chars = "/\r"
    for line in lines:
        if line.startswith("./"):
            result.append(line[2:].rstrip(strip_trailing_chars))
        else:
            result.append(line.rstrip(strip_trailing_chars))
    return result

################################################################################
def _verify_lifecycle_hooks_specified(state):
    if state.only_built_dependencies() == None:
        msg = """\
ERROR: pnpm 'allowBuilds' (or 'onlyBuiltDependencies' in pnpm < 10.26) configuration required.

Packages that rules_js should generate lifecycle hook actions for must be declared in
'allowBuilds' or 'onlyBuiltDependencies'.

As of pnpm v10.26 'allowBuilds' should be configured in the pnpm-workspace.yaml file.
See https://pnpm.io/settings#allowbuilds for more information.

As of pnpm v10 'onlyBuiltDependencies' should be configured in the pnpm-workspace.yaml file
alongside other pnpm configuration. See https://pnpm.io/10.x/settings#onlybuiltdependencies
for more information.

In pnpm v9 'onlyBuiltDependencies' is configured in the root package.json
pnpm.onlyBuiltDependencies. The root package.json must be alongside the pnpm-lock.yaml file
and will be automatically detected even if not explicitly added to data attribute.
See https://pnpm.io/9.x/package_json#pnpmonlybuiltdependencies for more information.
"""
        fail(msg)

################################################################################
def _verify_patches(rctx, attr, state):
    if attr.verify_patches and attr.patches != None:
        rctx.report_progress("Verifying patches in {}".format(attr.verify_patches))

        # Patches in the patch list verification file
        verify_patches_content = rctx.read(rctx.path(attr.verify_patches)).strip(" \t\n\r")
        verify_patches = sets.make(verify_patches_content.split("\n"))

        # Patches in `patches` or `pnpm.patchedDependencies`
        declared_patches = sets.make(state.pnpm_patches())

        # Patches in `npm_translate_lock(patches)`
        for patches in attr.patches.values():
            for patch in patches:
                patch_label = attr.pnpm_lock.relative(patch)
                sets.insert(declared_patches, paths.join(patch_label.package, patch_label.name))

        if not sets.is_subset(verify_patches, declared_patches):
            missing_patches = sets.to_list(sets.difference(verify_patches, declared_patches))
            missing_patches_formatted = "\n".join(["- %s" % path for path in missing_patches])
            fail("""
ERROR: in verify_patches:

The following patches were found in {patches_list} but were not listed in the 
`patches` attribute of `npm_translate_lock` or in `pnpm.patchedDependencies`.

{missing_patches}

To disable this check, remove the `verify_patches` attribute from `npm_translate_lock`.

""".format(patches_list = attr.verify_patches, missing_patches = missing_patches_formatted))

helpers = struct(
    gather_values_from_matching_names = _gather_values_from_matching_names,
    get_npm_auth = _get_npm_auth,
    credential_helper_for = _credential_helper_for,
    get_npm_imports = _get_npm_imports,
    link_package = _link_package,
    pnpm_auth_env = _pnpm_auth_env,
    pnpm_workspace_registries = _pnpm_workspace_registries,
    pnpm_workspace_registry_urls = _pnpm_workspace_registry_urls,
    to_apparent_repo_name = _to_apparent_repo_name,
    verify_node_modules_ignored = _verify_node_modules_ignored,
    verify_lifecycle_hooks_specified = _verify_lifecycle_hooks_specified,
    verify_patches = _verify_patches,
)

# exported for unit testing
helpers_testonly = struct(
    find_missing_bazel_ignores = _find_missing_bazel_ignores,
    gather_package_content_excludes = _gather_package_content_excludes,
    is_absolute_path = _is_absolute_path,
    select_npm_auth = _select_npm_auth,
)
