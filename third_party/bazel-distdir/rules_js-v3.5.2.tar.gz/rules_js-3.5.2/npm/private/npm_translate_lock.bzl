"Internal implementations"

load("@bazel_lib//lib:repo_utils.bzl", "repo_utils")
load("@bazel_lib//lib:write_source_files.bzl", "write_source_file")
load("@bazel_skylib//lib:paths.bzl", "paths")
load(":list_sources.bzl", "list_sources")
load(":npm_translate_lock_helpers.bzl", "helpers")
load(":npm_translate_lock_state.bzl", "npm_translate_lock_state")
load(":utils.bzl", "utils")

RULES_JS_FROZEN_PNPM_LOCK_ENV = "ASPECT_RULES_JS_FROZEN_PNPM_LOCK"

################################################################################

npm_translate_lock_lib = struct(
    doc = """Import a pnpm lock file and create `npm_import` rules to fetch each package.

These use Bazel's downloader to fetch the packages.
You can use this to redirect all fetches through a store like Artifactory.

See [Configuring Bazel's Downloader](https://blog.aspect.build/configuring-bazels-downloader)
for more info about how it works and how to configure it.

The [`npm_translate_lock`](#npm_translate_lock) module extension tag is the primary user-facing API.
It uses the lockfile format from [pnpm](https://pnpm.io/motivation) because it gives us reliable
semantics for how to dynamically lay out `node_modules` trees on disk in bazel-out.

To create `pnpm-lock.yaml`, consider using [`pnpm import`](https://pnpm.io/cli/import)
to preserve the versions pinned by your existing `package-lock.json` or `yarn.lock` file.

If you don't have an existing lock file, you can run `npx pnpm install --lockfile-only`.

Advanced users may want to directly fetch a package from npm rather than start from a lockfile,
[`npm_import`](./npm_import) does this.

### Generated repository layout

- A `defs.bzl` file containing some rules such as `npm_link_all_packages`, which are [documented here](./npm_link_all_packages.md).
- `BUILD` files declaring targets for the packages listed as `dependencies` or `devDependencies` in `package.json`,
    so you can declare dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
""",
    attrs = {
        "bins": attr.string_list_dict(doc = """
            Binary files to create in `node_modules/.bin` for packages in this lock file.

            For a given package, this is typically derived from the "bin" attribute in
            the package.json file of that package.

            For example:

            ```
            bins = {
                "@foo/bar": {
                    "foo": "./foo.js",
                    "bar": "./bar.js"
                },
            }
            ```

            Dicts of bins not additive. The most specific match wins.

            In the future, this field may be automatically populated from information in the pnpm lock
            file. That feature is currently blocked on https://github.com/pnpm/pnpm/issues/5131.

            Note: Bzlmod users must use an alternative syntax due to module extensions not supporting
            dict-of-dict attributes:

            ```
            bins = {
                "@foo/bar": [
                    "foo=./foo.js",
                    "bar=./bar.js"
                ],
            }
            ```
        """),
        "custom_postinstalls": attr.string_dict(doc = """"
            A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
            to a custom postinstall script to apply to the downloaded npm package after its lifecycle scripts runs.
            If the version is left out of the package name, the script will run on every version of the npm package. If
            a custom postinstall scripts exists for a package as well as for a specific version, the script for the versioned package
            will be appended with `&&` to the non-versioned package script.

            For example,

            ```
            custom_postinstalls = {
                "@foo/bar": "echo something > somewhere.txt",
                "fum@0.0.1": "echo something_else > somewhere_else.txt",
            },
            ```

            Custom postinstalls are additive and joined with ` && ` when there are multiple matches for a package.
            More specific matches are appended to previous matches.
        """),
        "credential_helpers": attr.label_keyed_string_dict(doc = """
            [Bazel credential helpers](https://bazel.build/reference/command-line-reference#flag--credential_helper)
            to authenticate `pnpm install` with when `update_pnpm_lock` is enabled, keyed by helper with the
            scope of registries it serves as the value, like the `[scope=]path` syntax of `--credential_helper`:

            ```
            credential_helpers = {
                "//tools:gcloud-helper": "*.pkg.dev",
                "//tools:github-helper": "npm.pkg.github.com",
                "//tools:default-helper": "",
            }
            ```

            A scope is a registry host, a `*.` wildcard matching a domain and its subdomains, or empty for every
            registry. A registry is matched the way Bazel does it: exact host first, then the most specific
            wildcard, then the unscoped helper. A registry no helper covers is left unauthenticated.

            Bazel's own `--credential_helper` flag only covers downloads made by Bazel, so `npm_import` fetches
            already honor it, but `pnpm install` run by `update_pnpm_lock` does not. Point this at the same helpers
            with the same scopes and rules_js invokes them with the credential helper protocol for the default
            registry and each registry declared in `pnpm-workspace.yaml` or the `.npmrc`, then passes the
            credentials to pnpm through its environment. No auth settings, or even an `.npmrc`, are needed for
            private registries.

            Only used when `update_pnpm_lock` is True. Requires pnpm 11 or newer.
        """),
        "data": attr.label_list(doc = """
            Data files required by this repository rule when auto-updating the pnpm lock file.

            Only needed when `update_pnpm_lock` is True.
            Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)
        """),
        "external_repository_action_cache": attr.string(default = utils.default_external_repository_action_cache(), doc = """
            The location of the external repository action cache to write to when `update_pnpm_lock` = True.
        """),
        "generate_bzl_library_targets": attr.bool(),
        "lifecycle_hooks_envs": attr.string_list_dict(doc = """
            Environment variables set for the lifecycle hooks actions on npm packages.
            The environment variables can be defined per package by package name or globally using "*".
            Variables are declared as key/value pairs of the form "key=value".
            Multiple matches are additive.

            Read more: [lifecycles](/docs/pnpm.md#lifecycles)
        """),
        "lifecycle_hooks": attr.string_list_dict(doc = """
            A dict of package names to list of lifecycle hooks to run for that package.

            By default the `preinstall`, `install` and `postinstall` hooks are run if they exist. This attribute allows
            the default to be overridden for packages to run `prepare`.

            List of hooks are not additive. The most specific match wins.

            Read more: [lifecycles](/docs/pnpm.md#lifecycles)
        """),
        "lifecycle_hooks_exclude": attr.string_list(default = [], doc = """
            A list of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
            to not run any lifecycle hooks on.

            Equivalent to adding `<value>: []` to `lifecycle_hooks`.

            Read more: [lifecycles](/docs/pnpm.md#lifecycles)
        """),
        "lifecycle_hooks_execution_requirements": attr.string_list_dict(doc = """
            Execution requirements applied to the preinstall, install and postinstall
            lifecycle hooks on npm packages.

            The execution requirements can be defined per package by package name or globally using "*".

            Execution requirements are not additive. The most specific match wins.

            Read more: [lifecycles](/docs/pnpm.md#lifecycles)
        """),
        "lifecycle_hooks_use_default_shell_env": attr.string_dict(doc = """
            The `use_default_shell_env` attribute of the lifecycle hooks
            actions on npm packages.

            See [use_default_shell_env](https://bazel.build/rules/lib/builtins/actions#run.use_default_shell_env)

            This defaults to False to reduce the negative effects of `use_default_shell_env`.

            Read more: [lifecycles](/docs/pnpm.md#lifecycles)
        """),
        "lifecycle_hooks_no_sandbox": attr.bool(default = True, doc = """
            If True, a "no-sandbox" execution requirement is added to all lifecycle hooks
            unless overridden by `lifecycle_hooks_execution_requirements`.

            Equivalent to adding `"*": ["no-sandbox"]` to `lifecycle_hooks_execution_requirements`.

            This defaults to True to limit the overhead of sandbox creation and copying the output
            TreeArtifacts out of the sandbox.

            Read more: [lifecycles](/docs/pnpm.md#lifecycles)
        """),
        "name": attr.string(),
        "no_dev": attr.bool(doc = "If True, `devDependencies` are not included"),
        "no_optional": attr.bool(doc = """
            If True, `optionalDependencies` are not installed.

            Currently `npm_translate_lock` behaves differently from pnpm in that it downloads all `optionalDependencies`
            while pnpm doesn't download `optionalDependencies` that are not needed for the platform pnpm is run on.
            See https://github.com/pnpm/pnpm/pull/3672 for more context.
        """),
        "node_toolchain_prefix": attr.string(default = "nodejs", doc = "the prefix of the node toolchain to use when generating the pnpm lockfile."),
        "npm_package_lock": attr.label(doc = """
            The `package-lock.json` file written by `npm install`.

            Only one of `npm_package_lock` or `yarn_lock` may be set.
        """),
        "npm_package_target_name": attr.string(default = "pkg", doc = """
            The name of linked `js_library`, `npm_package` or `JsInfo` producing targets.

            When targets are linked as pnpm workspace packages, the name of the target must align with this value.

            The `{dirname}` placeholder is replaced with the directory name of the target.
        """),
        "npmrc": attr.label(doc = """
            The `.npmrc` file, if any, to use.

            When set, the `.npmrc` file specified is parsed and npm auth tokens and basic authentication configuration
            specified in the file are passed to the Bazel downloader for authentication with private npm registries.

            `@scope:registry` entries route scoped packages to their registry. With pnpm 11 and newer, declare
            registries with the `registries` setting of `pnpm-workspace.yaml` instead; routing from `.npmrc` is
            kept for older pnpm versions and will be removed in rules_js 4.

            A [`tokenHelper`](https://pnpm.io/npmrc#urltokenhelper) is also honored: rules_js runs the executable it
            names and uses the token it prints on stdout. The helper path may be absolute or relative to this
            `.npmrc` file, and may reference environment variables. A helper runs during repository setup,
            only for a registry a package in the lockfile resolves to, and at most once per registry.

            SECURITY: unlike pnpm, which only runs a `tokenHelper` from user-level config, rules_js runs one declared
            in this `.npmrc` even when it is checked into the repository. A `tokenHelper` names an executable that
            rules_js runs during repository setup, so only set it to a helper you trust.

            In a future release, pnpm settings such as public-hoist-patterns will be used.
        """),
        "package_visibility": attr.string_list_dict(doc = """
            A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
            to a visibility list to use for the package's generated node_modules link targets. Multiple matches are additive.
            If there are no matches then the package's generated node_modules link targets default to public visibility
            (`["//visibility:public"]`).
        """),
        "patch_tool": attr.label(doc = "The patch tool to use. If not specified, the `patch` from `PATH` is used."),
        "patch_args": attr.string_list_dict(default = {"*": ["-p0"]}, doc = """
            A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
            to a label list arguments to pass to the patch tool. The most specific match wins.

            Read more: [patching](/docs/pnpm.md#patching)
        """),
        "patches": attr.string_list_dict(doc = """
            A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
            to a label list of patches to apply to the downloaded npm package. Multiple matches are additive.

            These patches are applied after any patches in [pnpm.patchedDependencies](https://pnpm.io/next/package_json#pnpmpatcheddependencies).

            Read more: [patching](/docs/pnpm.md#patching)
        """),
        "use_pnpm": attr.label(default = "@pnpm//:package/bin/pnpm.cjs", doc = "label of the pnpm entry point to use."),
        "pnpm_lock": attr.label(doc = "The `pnpm-lock.yaml` file, containing resolved and pinned package versions."),
        "preupdate": attr.label_list(doc = """
            Node.js scripts to run in this repository rule before auto-updating the pnpm lock file.

            Scripts are run sequentially in the order they are listed. The working directory is set to the root of the
            external repository. Make sure all files required by preupdate scripts are added to the `data` attribute.

            A preupdate script could, for example, transform `resolutions` in the root `package.json` file from a format
            that yarn understands such as `@foo/**/bar` to the equivalent `@foo/*>bar` that pnpm understands so that
            `resolutions` are compatible with pnpm when running `pnpm import` to update the pnpm lock file.

            Only needed when `update_pnpm_lock` is True.
            Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)
        """),
        "public_hoist_packages": attr.string_list_dict(doc = """
            A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
            to a list of Bazel packages in which to hoist the package to the top-level of the node_modules tree when linking.

            This is similar to setting https://pnpm.io/settings#publichoistpattern in an .npmrc file outside of Bazel, however,
            wild-cards are not yet supported and npm_translate_lock will fail if there are multiple versions of a package that
            are to be hoisted.

            ```
            public_hoist_packages = {
                "@foo/bar": [""] # link to the root package
                "fum@0.0.1": ["some/sub/package"]
            },
            ```

            List of public hoist packages are additive when there are multiple matches for a package. More specific matches
            are appended to previous matches.
        """),
        "quiet": attr.bool(default = True, doc = "Set to False to print info logs and output stdout & stderr of pnpm lock update actions to the console."),
        "run_lifecycle_hooks": attr.bool(default = True, doc = """
            Sets a default value for `lifecycle_hooks` if `*` not already set.
            Set this to `False` to disable lifecycle hooks.
        """),
        "update_pnpm_lock": attr.bool(doc = """
            When True, the pnpm lock file will be updated automatically when any of its inputs
            have changed since the last update.

            Defaults to True when one of `npm_package_lock` or `yarn_lock` are set.
            Otherwise it defaults to False.

            Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)
        """),
        "use_home_npmrc": attr.bool(doc = """
            Use the `$HOME/.npmrc` file (or `$USERPROFILE/.npmrc` when on Windows) if it exists.

            Settings from home `.npmrc` are merged with settings loaded from the `.npmrc` file specified
            in the `npmrc` attribute, if any. Where there are conflicting settings, the home `.npmrc` values
            will take precedence.

            WARNING: The repository rule will not be invalidated by changes to the home `.npmrc` file since there
            is no way to specify this file as an input to the repository rule. If changes are made to the home
            `.npmrc` you can force the repository rule to re-run and pick up the changes by running:
            `bazel run @{name}//:sync` where `name` is the name of the `npm_translate_lock` you want to re-run.

            Because of the repository rule invalidation issue, using the home `.npmrc` is not recommended.
            `.npmrc` settings should generally go in the `npmrc` in your repository so they are shared by all
            developers. The home `.npmrc` should be reserved for authentication settings for private npm repositories.
        """),
        "verify_node_modules_ignored": attr.label(doc = """
            **Bazel 7.x only (deprecated)** - Verifies node_modules folders are ignored.

            This points to a `.bazelignore` file to verify that all nested node_modules directories
            pnpm will create are listed.

            **Bazel 8+**: Use `ignore_directories(["**/node_modules"])` in REPO.bazel instead.

            See https://github.com/bazelbuild/bazel/issues/8106
        """),
        "verify_patches": attr.label(doc = """
            Label to a patch list file.

            Use this together with the `list_patches` macro to guarantee that all patches in a patch folder
            are included in the `patches` attribute.

            For example:

            ```
            verify_patches = "//patches:patches.list",
            ```

            In your patches folder add a BUILD.bazel file containing.
            ```
            load("@aspect_rules_js//npm:repositories.bzl", "list_patches")

            list_patches(
                name = "patches",
                out = "patches.list",
            )
            ```

            Once you have created this file, you need to create an empty `patches.list` file before generating the first list. You can do this by running
            ```
            touch patches/patches.list
            ```

            Finally, write the patches file at least once to make sure all patches are listed. This can be done by running `bazel run //patches:patches_update`.

            See the `list_patches` documentation for further info.
            NOTE: if you would like to customize the patches directory location, you can set a flag in the `.npmrc`. Here is an example of what this might look like
            ```
            # Set the directory for pnpm when patching
            # https://github.com/pnpm/pnpm/issues/6508#issuecomment-1537242124
            patches-dir=bazel/js/patches
            ```
            If you do this, you will have to update the `verify_patches` path to be this path instead of `//patches` like above.
        """),
        "yarn_lock": attr.label(doc = """
            The `yarn.lock` file written by `yarn install`.

            Only one of `npm_package_lock` or `yarn_lock` may be set.
        """),
    },
)

def parse_and_verify_lock(rctx, mod, attr):
    """Helper to parse and validate the lockfile

    Args:
        rctx: repository context
        mod: the module in which the extension is declared
        attr: attributes
    Returns:
        state, importers, and packages
    """

    state = npm_translate_lock_state.new(rctx, mod, attr)

    if state.should_update_pnpm_lock():
        # Run `pnpm install --lockfile-only` or `pnpm import` if its inputs have changed since last update
        if state.action_cache_miss():
            _fail_if_frozen_pnpm_lock(rctx, state)
            if _update_pnpm_lock(rctx, attr, state):
                msg = """

INFO: {} file updated. Please run your build again.

See https://github.com/aspect-build/rules_js/issues/1445
""".format(state.pnpm_lock_label())
                fail(msg)

    helpers.verify_node_modules_ignored(rctx, attr, state)

    helpers.verify_patches(rctx, attr, state)

    helpers.verify_lifecycle_hooks_specified(state)

    return state

################################################################################

def list_patches(name, out = None, include_patterns = ["*.diff", "*.patch"], exclude_package_contents = []):
    """Write a file containing a list of all patches in the current folder to the source tree.

    Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
    that all patches in a patch folder are included. This macro stamps a test to ensure the
    file stays up to date.

    Args:
        name: Name of the target
        out: Name of file to write to the source tree. If unspecified, `name` is used
        include_patterns: Patterns to pass to a glob of patch files
        exclude_package_contents: Patterns to ignore in a glob of patch files
    """
    outfile = out if out else name

    # Ignore the patch list file we generate
    exclude_package_contents = exclude_package_contents[:]
    exclude_package_contents.append(outfile)

    list_sources(
        name = "%s_list" % name,
        srcs = native.glob(include_patterns, exclude = exclude_package_contents),
    )

    write_source_file(
        name = "%s_update" % name,
        in_file = ":%s_list" % name,
        out_file = outfile,
    )

################################################################################
def _host_node_path(rctx, attr):
    # Note that we must reference the node binary under the platform-specific node
    # toolchain repository rather than under @nodejs_host since running rctx.path
    # (called outside this function) on the alias in the host repo fails under bzlmod.
    # It appears to fail because the platform-specific repository does not exist
    # unless we reference the label here.
    #
    # TODO: Try to understand this better and see if we can go back to using
    #  Label("@nodejs_host//:bin/node")
    return rctx.path(Label("@{}_{}//:bin/node".format(attr.node_toolchain_prefix, repo_utils.platform(rctx))))

################################################################################
def _execute_preupdate_scripts(rctx, attr, state):
    for script_label in attr.preupdate:
        rctx.report_progress("Executing preupdate Node.js script `{script}`".format(
            script = script_label,
        ))

        result = rctx.execute(
            [
                _host_node_path(rctx, attr),
                rctx.path(script_label),
            ],
            # To keep things simple, run at the root of the external repository
            working_directory = state.repo_root,
            quiet = attr.quiet,
        )
        if result.return_code:
            msg = """

ERROR: `node {script}` exited with status {status}.

       Make sure all package.json and other data files required for the running `node {script}` are added to
       the data attribute of `npm_translate_lock(name = "{rctx_name}")`.

STDOUT:
{stdout}
STDERR:
{stderr}
""".format(
                script = script_label,
                rctx_name = rctx.name,
                status = result.return_code,
                stderr = result.stderr,
                stdout = result.stdout,
            )
            fail(msg)

################################################################################
def _credential_helper_env(rctx, attr, state):
    helpers_by_scope = {scope: helper for helper, scope in attr.credential_helpers.items()}

    urls_by_helper = {}
    for url in state.registry_urls():
        helper = helpers.credential_helper_for(url, helpers_by_scope)
        if helper:
            urls_by_helper.setdefault(helper, []).append(url)

    env = {}
    for helper, urls in urls_by_helper.items():
        rctx.report_progress("Fetching registry credentials from `{}`".format(helper))

        result = rctx.execute(
            [
                _host_node_path(rctx, attr),
                rctx.path(Label("//npm/private:credential_helper.mjs")),
                rctx.path(helper),
            ] + urls,
            quiet = True,
        )
        if result.return_code:
            # stdout carries the credentials, so only stderr is reported
            fail("""

ERROR: credential helper `{helper}` of `npm_translate_lock(name = "{rctx_name}")` exited with status {status}.

STDERR:
{stderr}
""".format(
                helper = helper,
                rctx_name = attr.name,
                status = result.return_code,
                stderr = result.stderr,
            ))

        env.update(helpers.pnpm_auth_env(json.decode(result.stdout)))

    return env

################################################################################
def _update_pnpm_lock(rctx, attr, state):
    _execute_preupdate_scripts(rctx, attr, state)

    pnpm_lock_label = state.pnpm_lock_label()
    pnpm_lock_relative_path = paths.join(pnpm_lock_label.package, pnpm_lock_label.name)
    pnpm_lock_path = rctx.path(paths.join(state.repo_root, pnpm_lock_relative_path))

    update_cmd = ["import"] if attr.npm_package_lock or attr.yarn_lock else ["install", "--lockfile-only"]
    update_working_directory = paths.dirname(str(pnpm_lock_path))

    pnpm_cmd = " ".join(update_cmd)

    if not attr.quiet:
        # buildifier: disable=print
        print("""
INFO: Updating `{pnpm_lock}` file as its inputs have changed since the last update.
      Running `pnpm {pnpm_cmd}` in `{wd}`.
      To disable this feature set `update_pnpm_lock` to False in `npm_translate_lock(name = "{rctx_name}")`.""".format(
            pnpm_lock = pnpm_lock_relative_path,
            pnpm_cmd = pnpm_cmd,
            wd = update_working_directory,
            rctx_name = attr.name,
        ))

    rctx.report_progress("Updating pnpm-lock.yaml with `pnpm {pnpm_cmd}`".format(pnpm_cmd = pnpm_cmd))

    result = rctx.execute(
        [
            _host_node_path(rctx, attr),
            rctx.path(attr.use_pnpm),
        ] + update_cmd,
        environment = _credential_helper_env(rctx, attr, state),
        # Run pnpm in the external repository so that we are hermetic and all data files that are required need
        # to be specified. This requirement means that if any data file changes then the update command will be
        # re-run. For cases where all data files cannot be specified a user can simply turn off auto-updates
        # by setting update_pnpm_lock to False and update their pnpm-lock.yaml file manually.
        working_directory = update_working_directory,
        quiet = attr.quiet,
    )
    if result.return_code:
        msg = """

ERROR: `pnpm {cmd}` exited with status {status}.

       Make sure all package.json and other data files required for the running `pnpm {cmd}` are added to
       the data attribute of `npm_translate_lock(name = "{rctx_name}")`.

       If the problem persists, install pnpm (https://pnpm.io/installation) and run `pnpm {cmd}`
       manually to update the pnpm-lock.yaml file. If you have specified `preupdate` scripts in
       `npm_translate_lock(name = "{rctx_name}")` you may have to run these manually as well.

STDOUT:
{stdout}
STDERR:
{stderr}
""".format(
            cmd = " ".join(update_cmd),
            rctx_name = attr.name,
            status = result.return_code,
            stderr = result.stderr,
            stdout = result.stdout,
        )
        fail(msg)

    lockfile_changed = False
    if state.set_input_hash(
        pnpm_lock_relative_path,
        utils.hash(rctx.read(pnpm_lock_path)),
    ):
        # The lock file has changed
        if not attr.quiet:
            # buildifier: disable=print
            print("""
INFO: {} file has changed""".format(pnpm_lock_relative_path))
        utils.reverse_force_copy(rctx, pnpm_lock_label)
        lockfile_changed = True

    state.write_action_cache()

    return lockfile_changed

################################################################################
def _fail_if_frozen_pnpm_lock(rctx, state):
    if rctx.getenv(RULES_JS_FROZEN_PNPM_LOCK_ENV):
        fail("""

ERROR: `{action_cache}` is out of date. `{pnpm_lock}` may require an update. To update run,

           bazel run @@{rctx_name}//:sync

""".format(
            action_cache = state.action_cache_label(),
            pnpm_lock = state.pnpm_lock_label(),
            rctx_name = state.name(),
        ))
