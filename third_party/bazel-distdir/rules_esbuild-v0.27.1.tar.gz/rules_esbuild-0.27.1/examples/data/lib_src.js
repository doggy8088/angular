module.exports = "from-lib";
