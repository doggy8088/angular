#!/usr/bin/env bash
# Proves a few things about esbuild_bundle's `supports-path-mapping` execution
# requirement (esbuild/private/esbuild.bzl):
#
# 1. It lets Bazel's path mapping share a single cached action between two
#    builds that differ only in compilation mode.
# 2. It is advertised in the ordinary case.
# 3. It is not advertised when doing so would be unsafe, i.e. when a location
#    expansion in `define` produced a real, non-path-mapped path.
#
# A shared --disk_cache is required: -c opt and -c fastbuild are different
# configurations, so each gets its own action instance the first time Bazel
# visits it in a given build graph -- the incremental "did anything change"
# check within one build never gets a chance to compare across them. Only an
# explicit disk (or remote) cache lookup, keyed by the path-mapped action
# digest, can serve the second build's action from the first build's result.
set -o errexit -o nounset -o pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
disk_cache="$scratch/disk_cache"
exec_log="$scratch/exec_log.json"

# Force the esbuild action to be treated as new on every run of this script,
# so that a prior local build of the same target/config (e.g. from an earlier
# run of this script, or from another CI step) can't let Bazel skip it as
# already up-to-date -- we want every build here to genuinely consult (and
# thus prove something about) the shared --disk_cache. This is forwarded into
# the action's environment for free since the esbuild action already sets
# use_default_shell_env = True.
invalidate="$(date +%s)"

bazel build -c fastbuild //:bundle \
    --disk_cache="$disk_cache" \
    --action_env="ESBUILD_PATH_MAPPING_TEST_INVALIDATE=$invalidate"

bazel build -c opt //:bundle \
    --disk_cache="$disk_cache" \
    --action_env="ESBUILD_PATH_MAPPING_TEST_INVALIDATE=$invalidate" \
    --execution_log_json_file="$exec_log"

matches="$(jq -s '[.[] | select(.mnemonic == "esbuild")]' "$exec_log")"
count="$(echo "$matches" | jq 'length')"
if [ "$count" -eq 0 ]; then
    echo "FAIL: no esbuild entry found in the -c opt execution log" >&2
    exit 1
fi

cache_hit="$(echo "$matches" | jq -r '.[0].cacheHit')"
if [ "$cache_hit" != "true" ]; then
    echo "FAIL: action was re-executed under -c opt (cacheHit=$cache_hit); path mapping did not share the cache entry from -c fastbuild" >&2
    exit 1
fi

echo "PASS: action was cache-shared across -c fastbuild and -c opt"

# We should find via bazel aquery that the action advertises path-mapping
# support.
aquery_output="$(bazel aquery 'mnemonic("esbuild", //:bundle)')"
if ! echo "$aquery_output" | grep -q "supports-path-mapping"; then
    echo "FAIL: supports-path-mapping was not advertised for //:bundle" >&2
    echo "$aquery_output" >&2
    exit 1
fi

echo "PASS: supports-path-mapping is advertised for //:bundle"

# A location expansion in `define` (e.g. $(execpath ...)) can produce a real,
# config-specific path that isn't safe under path mapping, so esbuild_bundle
# must not advertise support for it in that case.
aquery_output="$(bazel aquery 'mnemonic("esbuild", //:bundle_with_location_expansion)')"
if echo "$aquery_output" | grep -q "supports-path-mapping"; then
    echo "FAIL: supports-path-mapping was advertised even though define used a location expansion" >&2
    echo "$aquery_output" >&2
    exit 1
fi

echo "PASS: path mapping is not advertised when define uses a location expansion"
