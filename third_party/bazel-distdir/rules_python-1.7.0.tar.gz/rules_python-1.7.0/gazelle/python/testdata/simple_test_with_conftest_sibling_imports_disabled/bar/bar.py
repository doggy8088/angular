def bar():
    return "bar"
