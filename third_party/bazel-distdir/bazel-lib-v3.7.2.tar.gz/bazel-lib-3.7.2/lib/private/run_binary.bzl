# Copyright 2019 The Bazel Authors. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""run_binary implementation"""

load("@bazel_skylib//lib:dicts.bzl", "dicts")
load("//lib:resource_sets.bzl", "resource_set", "resource_set_attr")
load("//lib:stamping.bzl", "STAMP_ATTRS", "maybe_stamp")
load(":expand_variables.bzl", "expand_variables")
load(":strings.bzl", "split_args")

def _bindir_path(file):
    return file.root.path

def _run_binary_impl(ctx):
    args = ctx.actions.args()

    outputs = []
    outputs.extend(ctx.outputs.outs)
    for _out_dir in ctx.attr.out_dirs:
        out_dir = ctx.actions.declare_directory(_out_dir)
        for output in outputs:
            if output.path.startswith(out_dir.path + "/"):
                fail("output {} is nested within output directory {}; outputs cannot be nested within each other!".format(output.path, out_dir.path))
            if output.is_directory and out_dir.path.startswith(output.path + "/"):
                fail("output directory {} is nested within output directory {}; outputs cannot be nested within each other!".format(out_dir.path, output.path))
        outputs.append(out_dir)

    # When a feature that requires interposing on the spawned process is requested
    # (capturing stdout/stderr/exit code, changing directory, or silencing output on
    # success), the tool is launched through the spawn_binary wrapper instead of
    # directly. When no such feature is used the tool is spawned directly, avoiding
    # the extra process and keeping the wrapper out of the action inputs entirely.
    #
    # The capture output files (stdout/stderr/exit_code_out) are real action outputs,
    # but are intentionally kept out of the make-variable output set (`outputs`, used
    # by $@ and $(@D)), so that a tool with a single declared `outs` file keeps
    # working with $@. They are only used for expansion when there is no other output.
    stdout = ctx.outputs.stdout
    stderr = ctx.outputs.stderr
    exit_code_out = ctx.outputs.exit_code_out
    silent_on_success = ctx.attr.silent_on_success
    chdir = ctx.attr.chdir
    fail_on = ctx.attr.fail_on
    use_wrapper = bool(stdout or stderr or exit_code_out or silent_on_success or chdir or fail_on)

    capture_outputs = [o for o in [stdout, stderr, exit_code_out] if o]
    action_outputs = outputs + capture_outputs
    expansion_outputs = outputs if outputs else action_outputs

    spawn_binary = None
    if use_wrapper:
        spawn_binary_toolchain = ctx.toolchains["//lib:spawn_binary_toolchain_type"]
        if not spawn_binary_toolchain:
            fail("run_binary target {} requests a feature that requires the spawn_binary toolchain (one of stdout, stderr, exit_code_out, silent_on_success, chdir, fail_on), but none is registered. Register it with register_spawn_binary_toolchains() (WORKSPACE) or the bazel_lib `spawn_binary` toolchain extension (bzlmod).".format(ctx.label))
        spawn_binary = spawn_binary_toolchain.spawn_binary_info.bin
        if stdout:
            args.add("--stdout", stdout)
        if stderr:
            args.add("--stderr", stderr)
        if exit_code_out:
            args.add("--exit-code-out", exit_code_out)
        if silent_on_success:
            args.add("--silent-on-success")
        for code in fail_on:
            args.add("--fail-on", str(code))

    if len(action_outputs) < 1:
        fail("""\
ERROR: target {target} is not configured to produce any outputs.

Bazel only executes actions when their outputs are required, so it's never correct to create an action with no outputs.

Possible fixes:
- Predict what outputs are created, and list them in the outs and out_dirs attributes.
- If {rule_kind} is a binary, and you meant to run it for its side-effects,
  then call it directly with `bazel run` and don't wrap it in a run_binary rule.
""".format(
            target = str(ctx.label),
            rule_kind = str(ctx.attr.tool.label),
        ))

    # Location and Make variable expansion can reference paths that aren't path mapped.
    can_path_map = True
    targets = ctx.attr.tools + ctx.attr.srcs
    inputs = ctx.files.tools + ctx.files.srcs

    if use_wrapper:
        if chdir:
            expanded_chdir = expand_variables(ctx, ctx.expand_location(chdir, targets = targets), inputs = inputs, outs = expansion_outputs, attribute_name = "chdir")

            # Path mapping rewrites action input/output paths in the sandbox. Only
            # advertise support when chdir is a literal path; $(location) / make
            # variable expansion can produce paths that must not be remapped.
            can_path_map = expanded_chdir == chdir
            args.add("--chdir", expanded_chdir)

        # The remaining args are the command to run: the tool followed by its args.
        args.add("--")
        args.add(ctx.executable.tool)

    for a in ctx.attr.args:
        if a == "$(BINDIR)":
            # As a special case, we expand arguments exactly equal to
            # "$(BINDIR)" directly, in a way that is compatible with path
            # mapping. Every output has the same bin directory, so we just
            # examine the first one. expand_directories is disabled since
            # the first output may be a not-yet-created output directory
            # (from out_dirs); we want its path, not its (currently
            # nonexistent) contents.
            args.add_all([expansion_outputs[0]], map_each = _bindir_path, expand_directories = False)
        else:
            expanded = expand_variables(ctx, ctx.expand_location(a, targets = targets), inputs = inputs, outs = expansion_outputs)

            # Disable path mapping if any location or variable expansion occurred
            can_path_map = can_path_map and expanded == a
            args.add_all(split_args(expanded))
    envs = {}
    for k, v in ctx.attr.env.items():
        envs[k] = expand_variables(ctx, ctx.expand_location(v, targets = targets), inputs = inputs, outs = expansion_outputs, attribute_name = "env")
        can_path_map = can_path_map and envs[k] == v

    stamp = maybe_stamp(ctx)
    if stamp:
        inputs = ctx.files.srcs + [stamp.volatile_status_file, stamp.stable_status_file]
        envs["BAZEL_STABLE_STATUS_FILE"] = stamp.stable_status_file.path
        envs["BAZEL_VOLATILE_STATUS_FILE"] = stamp.volatile_status_file.path
        can_path_map = False
    else:
        inputs = ctx.files.srcs

    if spawn_binary:
        executable = spawn_binary

        # Pass the wrapped tool via tools (rather than as the executable) so that
        # its runfiles are materialized and discoverable when spawn_binary execs it.
        tools = [ctx.attr.tool[DefaultInfo].files_to_run] + ctx.files.tools
        toolchain = "//lib:spawn_binary_toolchain_type"
    else:
        executable = ctx.executable.tool
        tools = ctx.files.tools
        toolchain = None

    ctx.actions.run(
        outputs = action_outputs,
        inputs = inputs,
        executable = executable,
        tools = tools,
        arguments = [args],
        resource_set = resource_set(ctx.attr),
        mnemonic = ctx.attr.mnemonic if ctx.attr.mnemonic else None,
        progress_message = ctx.attr.progress_message if ctx.attr.progress_message else None,
        # Target can override if they want to.
        execution_requirements = dicts.add({"supports-path-mapping": "1"} if can_path_map else {}, ctx.attr.execution_requirements),
        use_default_shell_env = ctx.attr.use_default_shell_env,
        env = dicts.add(ctx.configuration.default_shell_env, envs),
        toolchain = toolchain,
    )
    return DefaultInfo(
        files = depset(action_outputs),
        runfiles = ctx.runfiles(files = action_outputs),
    )

_run_binary = rule(
    implementation = _run_binary_impl,
    # Optional: only targets that request a wrapper feature (stdout, stderr,
    # exit_code_out, silent_on_success, chdir, fail_on) use the wrapper, so a plain run_binary
    # that spawns its tool directly does not require this toolchain to be registered.
    toolchains = [
        config_common.toolchain_type("//lib:spawn_binary_toolchain_type", mandatory = False),
    ],
    attrs = dicts.add({
        "tool": attr.label(
            executable = True,
            allow_files = True,
            mandatory = True,
            cfg = "exec",
        ),
        "tools": attr.label_list(
            allow_files = True,
            cfg = "exec",
        ),
        "env": attr.string_dict(),
        "srcs": attr.label_list(
            allow_files = True,
        ),
        "out_dirs": attr.string_list(),
        "outs": attr.output_list(),
        "stdout": attr.output(),
        "stderr": attr.output(),
        "exit_code_out": attr.output(),
        "chdir": attr.string(),
        "silent_on_success": attr.bool(),
        "fail_on": attr.int_list(),
        "args": attr.string_list(),
        "mnemonic": attr.string(),
        "progress_message": attr.string(),
        "execution_requirements": attr.string_dict(),
        "use_default_shell_env": attr.bool(),
    }, resource_set_attr, STAMP_ATTRS),
)

def run_binary(
        name,
        tool,
        srcs = [],
        args = [],
        env = {},
        outs = [],
        out_dirs = [],
        stdout = None,
        stderr = None,
        exit_code_out = None,
        chdir = None,
        silent_on_success = False,
        fail_on = [],
        mnemonic = "RunBinary",
        progress_message = None,
        execution_requirements = None,
        use_default_shell_env = False,
        stamp = 0,
        tools = [],
        **kwargs):
    """Runs a binary as a build action.

    This rule does not require Bash (unlike `native.genrule`).

    By default the binary is spawned directly. When any of the `stdout`, `stderr`,
    `exit_code_out`, `chdir`, `silent_on_success`, or `fail_on` attributes is set, the binary is
    instead launched through a small wrapper (`spawn_binary`) that provides these
    features. This is handy both to feed a program's output into a downstream action
    when the program has no flag to write it to a file, and to silence the output of
    otherwise-noisy successful build steps. The wrapper is only used when such a
    feature is requested, so the common case incurs no extra overhead.

    Args:
        name: The target name

        tool: The tool to run in the action.

            Must be the label of a *_binary rule of a rule that generates an executable file, or of
            a file that can be executed as a subprocess (e.g. an .exe or .bat file on Windows or a
            binary with executable permission on Linux). This label is available for `$(location)`
            expansion in `args` and `env`.
        srcs: Additional inputs of the action.

            These labels are available for `$(location)` expansion in `args` and `env`.

        args: Command line arguments of the binary.

            Subject to `$(location)` and make variable expansions via
            [expand_location](./expand_make_vars#expand_locations)
            and [expand_make_vars](./expand_make_vars).

        env: Environment variables of the action.

            Subject to `$(location)` and make variable expansions via
            [expand_location](./expand_make_vars#expand_locations)
            and [expand_make_vars](./expand_make_vars).

        outs: Output files generated by the action.

            These labels are available for `$(location)` expansion in `args` and `env`.

            Output files cannot be nested within output directories in out_dirs.

        out_dirs: Output directories generated by the action.

            These labels are _not_ available for `$(location)` expansion in `args` and `env` since
            they are not pre-declared labels created via `attr.output_list()`. Output directories are
            declared instead by `ctx.actions.declare_directory`.

            Output directories cannot be nested within other output directories in out_dirs.

        stdout: Output file to capture the stdout of the binary to.

            When set, the binary is launched through a small wrapper that redirects its
            standard output to this file. The file can later be used as an input to
            another target, subject to the same semantics as `outs`. If the binary also
            creates declared outputs, those must still be created.

            Standard input is always passed through to the binary unchanged. When none of
            the wrapper features are set, the binary is spawned directly without the wrapper.

        stderr: Output file to capture the stderr of the binary to.

            Behaves like `stdout`, but for the standard error stream. The file can later
            be used as an input to another target, subject to the same semantics as `outs`.

        exit_code_out: Output file to capture the exit code of the binary to.

            When set, the binary is allowed to exit non-zero without failing the action:
            its exit code is written to this file (as a decimal string) and the action
            itself succeeds. Any declared `outs`/`out_dirs` must still be created. This is
            useful to record the result of a tool whose failure should be handled by a
            downstream target rather than breaking the build.

            When `fail_on` is also set, only the listed exit codes fail the action; the
            exit code is still written to this file.

        fail_on: Exit codes that should fail the action.

            When set, the binary is launched through the spawn_binary wrapper and only the
            listed exit codes cause the action to fail. All other exit codes are treated
            as success. This is useful for tools such as `diff` that use non-zero exit
            codes for non-error conditions (for example exit `1` when files differ and
            exit `2` on error, or exit `0` when `grep` finds a match). Can be combined
            with `exit_code_out` to record the exit code while still failing the action
            on specific codes. `silent_on_success` uses the same success/failure decision
            when deciding whether to forward buffered output.

        chdir: Working directory to run the binary in.

            When set, the binary is run with this as its working directory instead of the
            execution root. Subject to `$(location)` and make variable expansions. Note
            that paths in `args`/`env` are expanded relative to the execution root, so a
            program that receives such paths and is also given a `chdir` typically needs
            absolute paths (for example via `$(execpath ...)` combined with `$(RULEDIR)`).

        silent_on_success: Suppress the binary's output unless it fails.

            When True, stdout and stderr that are not being captured to a file are buffered
            and only forwarded to the console if the action is treated as a failure. With
            `fail_on`, that means exit codes listed in `fail_on`; otherwise a non-zero
            exit code. This silences logspam from successful build steps while preserving
            diagnostics on failure.

        mnemonic: A one-word description of the action, for example, CppCompile or GoLink.

        progress_message: Progress message to show to the user during the build, for example,
            "Compiling foo.cc to create foo.o". The message may contain %{label}, %{input}, or
            %{output} patterns, which are substituted with label string, first input, or output's
            path, respectively. Prefer to use patterns instead of static strings, because the former
            are more efficient.

        execution_requirements: Information for scheduling the action.

            For example,

            ```
            execution_requirements = {
                "no-cache": "1",
            },
            ```

            See https://docs.bazel.build/versions/main/be/common-definitions.html#common.tags for useful keys.

        use_default_shell_env: Passed to the underlying ctx.actions.run.

            May introduce non-determinism when True; use with care!
            See e.g. https://github.com/bazelbuild/bazel/issues/4912

            Refer to https://bazel.build/rules/lib/builtins/actions#run for more details.

        stamp: Whether to include build status files as inputs to the tool. Possible values:

            - `stamp = 0` (default): Never include build status files as inputs to the tool.
                This gives good build result caching.
                Most tools don't use the status files, so including them in `--stamp` builds makes those
                builds have many needless cache misses.
                (Note: this default is different from most rules with an integer-typed `stamp` attribute.)
            - `stamp = 1`: Always include build status files as inputs to the tool, even in
                [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
                This setting should be avoided, since it is non-deterministic.
                It potentially causes remote cache misses for the target and
                any downstream actions that depend on the result.
            - `stamp = -1`: Inclusion of build status files as inputs is controlled by the
                [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
                Stamped targets are not rebuilt unless their dependencies change.

            When stamping is enabled, an additional two environment variables will be set for the action:
                - `BAZEL_STABLE_STATUS_FILE`
                - `BAZEL_VOLATILE_STATUS_FILE`

            These files can be read and parsed by the action, for example to pass some values to a linker.

        tools: A list of tool dependencies for this action.

            These are treated similarly to srcs, except that they are built in
            the exec configuration. Any code that will be executed as part of
            the action should generally be listed here instead of in srcs.

        **kwargs: Additional arguments
    """
    _run_binary(
        name = name,
        tool = tool,
        srcs = srcs,
        tools = tools,
        args = args,
        env = env,
        outs = outs,
        out_dirs = out_dirs,
        stdout = stdout,
        stderr = stderr,
        exit_code_out = exit_code_out,
        chdir = chdir,
        silent_on_success = silent_on_success,
        fail_on = fail_on,
        mnemonic = mnemonic,
        progress_message = progress_message,
        execution_requirements = execution_requirements,
        use_default_shell_env = use_default_shell_env,
        stamp = stamp,
        **kwargs
    )
