module github.com/bazel-contrib/bazel-lib

go 1.25.0

require (
	github.com/bazelbuild/rules_go v0.62.0
	github.com/bmatcuk/doublestar/v4 v4.10.0
	golang.org/x/exp v0.0.0-20260727155853-b88d891fe743
	golang.org/x/sys v0.47.0
)
