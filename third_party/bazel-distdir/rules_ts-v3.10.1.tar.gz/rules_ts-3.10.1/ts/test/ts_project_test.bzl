"UnitTests for ts_project"

load("@aspect_rules_js//js:providers.bzl", "JsInfo")
load("@bazel_skylib//lib:unittest.bzl", "analysistest", "asserts")
load("@bazel_skylib//rules:build_test.bzl", "build_test")
load("@bazel_skylib//rules:write_file.bzl", "write_file")
load("//ts:defs.bzl", "ts_project")

# dir_test
def _dir_test_impl(ctx):
    env = analysistest.begin(ctx)
    target_under_test = analysistest.target_under_test(env)

    # assert the inputs to the tsc action are what we expect
    action_inputs = target_under_test[OutputGroupInfo]._action_inputs.to_list()
    action_inputs = sorted(action_inputs)
    asserts.equals(env, 2, len(action_inputs))
    asserts.true(env, action_inputs[0].path.find("/dir.ts") != -1)
    asserts.true(env, action_inputs[1].path.find("/tsconfig_dir.json") != -1)

    # sources should contain the .js output
    sources = target_under_test[JsInfo].sources.to_list()
    asserts.equals(env, 2, len(sources))
    asserts.true(env, sources[0].path.find("/dir.js") != -1)
    asserts.true(env, sources[1].path.find("/dir.js.map") != -1)

    # transitive_sources should contain the .js output
    transitive_sources = target_under_test[JsInfo].transitive_sources.to_list()
    asserts.equals(env, 2, len(transitive_sources))
    asserts.true(env, transitive_sources[0].path.find("/dir.js") != -1)
    asserts.true(env, transitive_sources[1].path.find("/dir.js.map") != -1)

    # types should only have the source types
    types = target_under_test[JsInfo].types.to_list()
    asserts.equals(env, 1, len(types))
    asserts.true(env, types[0].path.find("/dir.d.ts") != -1)

    # transitive_types should have the source types and transitive types
    transitive_types = target_under_test[JsInfo].transitive_types.to_list()
    asserts.equals(env, 1, len(transitive_types))
    asserts.true(env, transitive_types[0].path.find("/dir.d.ts") != -1)

    # types OutputGroupInfo should be the same as types
    asserts.equals(env, types, target_under_test[OutputGroupInfo].types.to_list())

    return analysistest.end(env)

_dir_test = analysistest.make(_dir_test_impl)

# use_dir_test
def _use_dir_test_impl(ctx):
    env = analysistest.begin(ctx)
    target_under_test = analysistest.target_under_test(env)

    # assert the inputs to the tsc action are what we expect;
    # the inputs should *NOT* includes the sources from any deps or transitive deps;
    # only types from deps should be included as action inputs.
    action_inputs = target_under_test[OutputGroupInfo]._action_inputs.to_list()
    action_inputs = sorted([f.path for f in action_inputs])
    asserts.equals(env, 3, len(action_inputs))
    asserts.true(env, action_inputs[0].find("/dir.d.ts") != -1)
    asserts.true(env, action_inputs[1].find("/tsconfig_use_dir.json") != -1)
    asserts.true(env, action_inputs[2].find("/use_dir.ts") != -1)

    # sources should contain the .js output
    sources = target_under_test[JsInfo].sources.to_list()
    sources = sorted([f.path for f in sources])
    asserts.equals(env, 2, len(sources))
    asserts.true(env, sources[0].find("/use_dir.js") != -1)
    asserts.true(env, sources[1].find("/use_dir.js.map") != -1)

    # transitive_sources should contain the .js output
    transitive_sources = target_under_test[JsInfo].transitive_sources.to_list()
    transitive_sources = sorted([f.path for f in transitive_sources])
    asserts.equals(env, 4, len(transitive_sources))
    asserts.true(env, transitive_sources[0].find("/dir.js") != -1)
    asserts.true(env, transitive_sources[1].find("/dir.js.map") != -1)
    asserts.true(env, transitive_sources[2].find("/use_dir.js") != -1)
    asserts.true(env, transitive_sources[3].find("/use_dir.js.map") != -1)

    # types should only have the source types
    types = target_under_test[JsInfo].types.to_list()
    types = sorted([f.path for f in types])
    asserts.equals(env, 1, len(types))
    asserts.true(env, types[0].find("/use_dir.d.ts") != -1)

    # transitive_types should have the source types and transitive types
    transitive_types = target_under_test[JsInfo].transitive_types.to_list()
    transitive_types = sorted([f.path for f in transitive_types])
    asserts.equals(env, 2, len(transitive_types))
    asserts.true(env, transitive_types[0].find("/dir.d.ts") != -1)
    asserts.true(env, transitive_types[1].find("/use_dir.d.ts") != -1)

    # types OutputGroupInfo should be the same as types
    types_group = target_under_test[OutputGroupInfo].types.to_list()
    types_group = sorted([f.path for f in types_group])
    asserts.equals(env, types, types_group)

    return analysistest.end(env)

_use_dir_test = analysistest.make(_use_dir_test_impl)

# Use a dict() defined at the top level so it gets analyzed as part of .bzl file loading
# and is therefore immutable. See https://bazel.build/rules/language#mutability
_TSCONFIG = {
    "compilerOptions": {
        "declaration": True,
        "sourceMap": True,
    },
}

_TSCONFIG_JS_ONLY = {
    "compilerOptions": {
        "declaration": False,
    },
}

# no_decl_lib_transitive_typecheck_test
# Verifies that when declaration=False, js_outs appear in transitive_typecheck (the fix).
def _no_decl_lib_transitive_typecheck_test_impl(ctx):
    env = analysistest.begin(ctx)
    target = analysistest.target_under_test(env)

    files = target[OutputGroupInfo].transitive_typecheck.to_list()
    asserts.equals(env, 1, len(files))
    asserts.true(env, files[0].path.find(".js") != -1)

    return analysistest.end(env)

_no_decl_lib_transitive_typecheck_test = analysistest.make(_no_decl_lib_transitive_typecheck_test_impl)

# no_decl_consumer_transitive_typecheck_test
# Verifies that transitive_typecheck chains correctly through declaration=False deps.
def _no_decl_consumer_transitive_typecheck_test_impl(ctx):
    env = analysistest.begin(ctx)
    target = analysistest.target_under_test(env)

    files = target[OutputGroupInfo].transitive_typecheck.to_list()
    asserts.equals(env, 2, len(files))

    return analysistest.end(env)

_no_decl_consumer_transitive_typecheck_test = analysistest.make(_no_decl_consumer_transitive_typecheck_test_impl)

def ts_project_test_suite(name):
    """Test suite including all tests and data

    Args:
        name: Target name of the test_suite target.
    """

    write_file(
        name = "dir_ts",
        out = "dir.ts",
        content = ["import { dirname } from 'path'; export const dir = dirname(__filename);"],
        tags = ["manual"],
    )
    ts_project(
        name = "dir",
        srcs = ["dir.ts"],
        tsconfig = _TSCONFIG,
        tags = ["manual"],
    )
    _dir_test(
        name = "dir_test",
        target_under_test = "dir",
    )

    write_file(
        name = "use_dir_ts",
        out = "use_dir.ts",
        content = ["import { dir } from './dir'; export const another_dir = dir;"],
        tags = ["manual"],
    )
    ts_project(
        name = "use_dir",
        srcs = ["use_dir.ts"],
        deps = ["dir"],
        tsconfig = _TSCONFIG,
        tags = ["manual"],
    )
    _use_dir_test(
        name = "use_dir_test",
        target_under_test = "use_dir",
    )

    write_file(
        name = "wrapper_ts",
        out = "wrapper.ts",
        content = ["console.log(1)"],
        tags = ["manual"],
    )
    ts_project_wrapper(
        name = "wrapper",
        srcs = ["wrapper.ts"],
        declaration_map = True,  # a value that will override the tsconfig dict()
        tsconfig = _TSCONFIG,
        tags = ["manual"],
    )

    build_test(
        name = "wrapper_test",
        targets = [":wrapper.d.ts.map"],
    )

    write_file(
        name = "dirty_out_dir_ts",
        out = "dirty_out_dir.ts",
        content = ["console.log(1)"],
        tags = ["manual"],
    )
    ts_project_wrapper(
        name = "dirty_out_dir",
        srcs = ["dirty_out_dir.ts"],
        out_dir = "./out-dir",
        tsconfig = _TSCONFIG,
        tags = ["manual"],
    )

    build_test(
        name = "dirty_out_dir_test",
        targets = [":dirty_out_dir"],
    )

    # Path-normalization tests: verify that ./path, path/, and ./path/ are all
    # accepted as equivalent for outDir, declarationDir, and rootDir together.
    # Each variant uses a distinct directory tree so outputs never conflict.

    # Leading ./: tsconfig uses ./out1, ./types1, ./nrm1
    write_file(
        name = "path_norm1_ts",
        out = "nrm1/src1.ts",
        content = ["export const x = 1"],
        tags = ["manual"],
    )
    ts_project_wrapper(
        name = "path_norm_dotslash",
        srcs = [":path_norm1_ts"],
        declaration = True,
        tsconfig = {
            "compilerOptions": {
                "outDir": "./out1",
                "declaration": True,
                "declarationDir": "./types1",
                "rootDir": "./nrm1",
            },
            "exclude": [],
        },
        tags = ["manual"],
    )
    build_test(
        name = "path_norm_dotslash_test",
        targets = [":path_norm_dotslash"],
    )

    # Trailing /: tsconfig uses out2/, types2/, nrm2/
    write_file(
        name = "path_norm2_ts",
        out = "nrm2/src2.ts",
        content = ["export const x = 1"],
        tags = ["manual"],
    )
    write_file(
        name = "tsconfig_path_norm_trailing_slash",
        out = "tsconfig_path_norm_trailing_slash.json",
        content = ['{"files": ["nrm2/src2.ts"], "compilerOptions": {"outDir": "out2/", "declaration": true, "declarationDir": "types2/", "rootDir": "nrm2/"}, "exclude": []}'],
        tags = ["manual"],
    )
    ts_project_wrapper(
        name = "path_norm_trailing_slash",
        srcs = [":path_norm2_ts"],
        declaration = True,
        out_dir = "out2",
        declaration_dir = "types2",
        root_dir = "nrm2",
        tsconfig = ":tsconfig_path_norm_trailing_slash",
        tags = ["manual"],
    )
    build_test(
        name = "path_norm_trailing_slash_test",
        targets = [":path_norm_trailing_slash"],
    )

    # Both ./ and /: tsconfig uses ./out3/, ./types3/, ./nrm3/
    write_file(
        name = "path_norm3_ts",
        out = "nrm3/src3.ts",
        content = ["export const x = 1"],
        tags = ["manual"],
    )
    write_file(
        name = "tsconfig_path_norm_both_slash",
        out = "tsconfig_path_norm_both_slash.json",
        content = ['{"files": ["nrm3/src3.ts"], "compilerOptions": {"outDir": "./out3/", "declaration": true, "declarationDir": "./types3/", "rootDir": "./nrm3/"}, "exclude": []}'],
        tags = ["manual"],
    )
    ts_project_wrapper(
        name = "path_norm_both_slash",
        srcs = [":path_norm3_ts"],
        declaration = True,
        out_dir = "out3",
        declaration_dir = "types3",
        root_dir = "nrm3",
        tsconfig = ":tsconfig_path_norm_both_slash",
        tags = ["manual"],
    )
    build_test(
        name = "path_norm_both_slash_test",
        targets = [":path_norm_both_slash"],
    )

    write_file(
        name = "no_decl_lib_ts",
        out = "no_decl_lib.ts",
        content = ["export const x = 1;"],
        tags = ["manual"],
    )
    ts_project(
        name = "no_decl_lib",
        srcs = ["no_decl_lib.ts"],
        tsconfig = _TSCONFIG_JS_ONLY,
        tags = ["manual"],
    )
    _no_decl_lib_transitive_typecheck_test(
        name = "no_decl_lib_transitive_typecheck_analysis_test",
        target_under_test = "no_decl_lib",
    )

    write_file(
        name = "no_decl_consumer_ts",
        out = "no_decl_consumer.ts",
        content = ["export const y = 2;"],
        tags = ["manual"],
    )
    ts_project(
        name = "no_decl_consumer",
        srcs = ["no_decl_consumer.ts"],
        deps = [":no_decl_lib"],
        tsconfig = _TSCONFIG_JS_ONLY,
        tags = ["manual"],
    )
    _no_decl_consumer_transitive_typecheck_test(
        name = "no_decl_consumer_transitive_typecheck_analysis_test",
        target_under_test = "no_decl_consumer",
    )

    native.test_suite(
        name = name,
        tests = [
            ":dir_test",
            ":use_dir_test",
            ":wrapper_test",
            ":dirty_out_dir_test",
            ":path_norm_dotslash_test",
            ":path_norm_trailing_slash_test",
            ":path_norm_both_slash_test",
            ":no_decl_lib_transitive_typecheck_analysis_test",
            ":no_decl_consumer_transitive_typecheck_analysis_test",
        ],
    )

def ts_project_wrapper(name, **kwargs):
    ts_project(
        name = name,
        **kwargs
    )
